@echo off
python src/experimento_repetibilidad_equipo01.py --mock
pause
