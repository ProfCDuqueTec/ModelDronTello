"""
Sesión 6 — Bloque 5: Equipo 1, Repetibilidad experimental
MR2023 Modelación para Automatización

Extensión mínima de experimento_patron_tello_v3.py.

Objetivo didáctico:
    Ejecutar tres repeticiones del mismo escalón vertical relativo:

        h0_real -> h0_real + step_cm

    y generar evidencia para responder:

        ¿El dron responde igual ante la misma entrada experimental?

Uso recomendado con dron real:
    python src/experimento_repetibilidad_equipo01.py

Uso sin dron para prueba del flujo:
    python src/experimento_repetibilidad_equipo01.py --mock

Salidas principales:
    datos/equipo01_repetibilidad_030cm_rep01.csv
    datos/equipo01_repetibilidad_030cm_rep02.csv
    datos/equipo01_repetibilidad_030cm_rep03.csv
    datos/equipo01_repetibilidad_resumen.csv
    salidas/equipo01_repetibilidad_comparacion.png
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from experimento_patron_tello_v3 import (
    ExperimentConfig,
    TelemetryRecorder,
    create_drone,
    ensure_output_dirs,
    median_height_cm,
    plot_results,
    print_quality_check,
    safe_get_battery,
    safe_land,
    save_results,
    validate_config_for_real_drone,
)


MISSION_NAME = "Equipo 1 — Repetibilidad experimental"
MISSION_QUESTION = "¿El dron responde igual ante la misma entrada experimental?"


def build_rep_config(base: ExperimentConfig, rep: int, prefix: str) -> ExperimentConfig:
    """Crea una configuración de salida para cada repetición sin cambiar la lógica del experimento patrón."""
    step_tag = f"{base.step_cm:03d}cm"
    stem = f"{prefix}_{step_tag}_rep{rep:02d}"
    return ExperimentConfig(
        step_cm=base.step_cm,
        initial_hold_s=base.initial_hold_s,
        after_step_hold_s=base.after_step_hold_s,
        sample_period_s=base.sample_period_s,
        min_battery_percent=base.min_battery_percent,
        max_allowed_final_height_cm=base.max_allowed_final_height_cm,
        min_allowed_initial_height_cm=base.min_allowed_initial_height_cm,
        max_allowed_initial_height_cm=base.max_allowed_initial_height_cm,
        takeoff_settle_s=base.takeoff_settle_s,
        command_speed_cm_s=base.command_speed_cm_s,
        output_csv=f"datos/{stem}.csv",
        output_plot=f"salidas/{stem}.png",
        output_metadata=f"datos/{stem}_metadata.json",
    )


def estimate_basic_metrics(df: pd.DataFrame, step_cm: int) -> dict[str, float]:
    """Calcula métricas preliminares de cada repetición para comparación rápida.

    No sustituye el análisis formal de la tarea; solo ayuda a validar si las tres curvas son útiles.
    """
    if df.empty:
        return {}

    before = df[df["fase"] == "antes_del_escalon"] if "fase" in df.columns else pd.DataFrame()
    after = df[df["fase"] == "despues_del_escalon"] if "fase" in df.columns else pd.DataFrame()
    during = df[df["fase"] == "durante_comando_up"] if "fase" in df.columns else pd.DataFrame()

    h0 = float(before["altura"].median()) if not before.empty else float(df["altura"].iloc[:10].mean())
    hf = float(after["altura"].tail(10).mean()) if not after.empty else float(df["altura"].iloc[-10:].mean())
    delta_h = hf - h0
    delta_r = step_cm / 100.0
    k_est = delta_h / delta_r if delta_r != 0 else float("nan")

    t_start = float(during["tiempo"].min()) if not during.empty else float(df["tiempo"].iloc[0])
    h63 = h0 + 0.632 * delta_h
    post = df[df["tiempo"] >= t_start].copy()

    tau = float("nan")
    t63 = float("nan")
    if not post.empty and delta_h > 0:
        reached = post[post["altura"] >= h63]
        if not reached.empty:
            t63 = float(reached["tiempo"].iloc[0])
            tau = t63 - t_start

    overshoot_m = float(df["altura"].max() - hf)
    rms_to_reference = float(math.sqrt(((df["altura"] - df["referencia"]) ** 2).mean()))

    return {
        "h0_m": h0,
        "hf_m": hf,
        "delta_h_m": delta_h,
        "delta_r_m": delta_r,
        "K_preliminar": k_est,
        "h63_m": h63,
        "t_inicio_escalon_s": t_start,
        "t63_s": t63,
        "tau_preliminar_s": tau,
        "sobreimpulso_aprox_m": overshoot_m,
        "rms_altura_vs_referencia_m": rms_to_reference,
        "muestras": float(len(df)),
        "duracion_s": float(df["tiempo"].max() - df["tiempo"].min()),
    }


def run_single_repetition(rep: int, total_reps: int, mock: bool, config: ExperimentConfig) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Ejecuta una repetición completa: conectar, despegar, registrar, aplicar escalón, aterrizar y guardar."""
    validate_config_for_real_drone(config, mock)
    ensure_output_dirs(config)

    drone = create_drone(mock)
    metadata: dict[str, Any] = {
        "curso": "MR2023 Modelación para Automatización",
        "sesion": "Sesión 6",
        "bloque": "Bloque 5 — Campaña experimental por equipos",
        "equipo": 1,
        "mision": MISSION_NAME,
        "pregunta_investigacion": MISSION_QUESTION,
        "repeticion": rep,
        "total_repeticiones": total_reps,
        "experimento": "Repetición de escalón relativo de altura desde hover estable",
        "configuracion": asdict(config),
        "modo_mock": mock,
        "timestamp_inicio": time.strftime("%Y-%m-%d %H:%M:%S"),
        "nota": (
            "Extensión mínima de v3. Se usa h0 real estable y se aplica el mismo escalón relativo "
            "en cada repetición para evaluar repetibilidad experimental."
        ),
    }

    airborne = False
    recorder: TelemetryRecorder | None = None

    try:
        print("\n" + "=" * 72)
        print(f"{MISSION_NAME} | Repetición {rep}/{total_reps}")
        print("=" * 72)
        print("Conectando con el dron...")
        drone.connect()
        battery = safe_get_battery(drone)
        metadata["bateria_inicial"] = battery
        print(f"Batería inicial: {battery:.0f} %")

        if not mock and battery < config.min_battery_percent:
            raise RuntimeError(f"Batería insuficiente. Se recomienda al menos {config.min_battery_percent} %.")

        input("\nVerifica zona despejada y autorización del profesor. Presiona ENTER para despegar...")

        print("Despegando...")
        drone.takeoff()
        airborne = True
        time.sleep(config.takeoff_settle_s)

        try:
            drone.set_speed(config.command_speed_cm_s)
            print(f"Velocidad de comando configurada: {config.command_speed_cm_s} cm/s")
        except Exception as exc:  # noqa: BLE001
            print(f"[ADVERTENCIA] No se pudo configurar velocidad: {exc}")

        h0_cm = median_height_cm(drone, n=9, sample_period_s=0.08)
        if math.isnan(h0_cm):
            raise RuntimeError("No se pudo medir la altura inicial estable.")

        h0_cm = float(round(h0_cm))
        hf_cm = h0_cm + config.step_cm

        print("\nCondición inicial aceptada sin ajuste automático de altura")
        print(f"Altura inicial real medida: {h0_cm:.0f} cm")
        print(f"Escalón relativo aplicado: +{config.step_cm} cm")
        print(f"Referencia experimental: {h0_cm:.0f} cm -> {hf_cm:.0f} cm")
        print(f"Muestreo objetivo: {1/config.sample_period_s:.1f} Hz")

        if h0_cm < config.min_allowed_initial_height_cm or h0_cm > config.max_allowed_initial_height_cm:
            raise RuntimeError(
                f"Altura inicial fuera de rango seguro: {h0_cm:.0f} cm. "
                f"Rango recomendado: {config.min_allowed_initial_height_cm}–{config.max_allowed_initial_height_cm} cm."
            )

        if hf_cm > config.max_allowed_final_height_cm:
            raise RuntimeError(
                f"La altura final estimada sería {hf_cm:.0f} cm, mayor que el límite de clase "
                f"({config.max_allowed_final_height_cm} cm). Reduce --step-cm."
            )

        metadata["altura_inicial_real_cm"] = h0_cm
        metadata["altura_final_referencia_cm"] = hf_cm
        metadata["step_cm"] = config.step_cm

        recorder = TelemetryRecorder(drone=drone, config=config)
        recorder.set_state(phase="antes_del_escalon", reference_cm=h0_cm)
        recorder.start()

        time.sleep(config.initial_hold_s)

        print(f"\nAplicando escalón de repetibilidad: move_up({config.step_cm} cm)...")
        metadata["tiempo_aplicacion_escalon_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_up", reference_cm=hf_cm)

        drone.move_up(config.step_cm)

        metadata["tiempo_fin_comando_s"] = recorder.elapsed()
        metadata["duracion_comando_s"] = metadata["tiempo_fin_comando_s"] - metadata["tiempo_aplicacion_escalon_s"]
        recorder.set_state(phase="despues_del_escalon", reference_cm=hf_cm)

        time.sleep(config.after_step_hold_s)
        recorder.stop()

        print("\nAterrizando...")
        aterrizo_ok = safe_land(drone)
        airborne = False
        if not aterrizo_ok:
            raise RuntimeError("El aterrizaje automático falló. Revisar dron antes de repetir la práctica.")

        metadata["timestamp_fin"] = time.strftime("%Y-%m-%d %H:%M:%S")
        metadata["bateria_final"] = safe_get_battery(drone)

        df = save_results(recorder.samples, config, metadata)
        plot_results(df, config)
        print_quality_check(df)

        metrics = estimate_basic_metrics(df, config.step_cm)
        metadata["metricas_preliminares"] = metrics
        with open(config.output_metadata, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=4, ensure_ascii=False)

        print(f"\nRepetición {rep}/{total_reps} completada correctamente.")
        return df, metadata

    except KeyboardInterrupt:
        print("\nInterrupción manual detectada.")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando aterrizar por seguridad...")
            safe_land(drone)
        raise

    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR] Repetición {rep}: {exc}")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando estabilizar y aterrizar por seguridad...")
            safe_land(drone)
        raise

    finally:
        try:
            if hasattr(drone, "is_flying") and not getattr(drone, "is_flying"):
                drone.end()
            elif not airborne:
                drone.end()
        except Exception:
            pass


def save_repetition_summary(metadatas: list[dict[str, Any]], prefix: str) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for meta in metadatas:
        row: dict[str, Any] = {
            "repeticion": meta.get("repeticion"),
            "archivo_csv": meta.get("configuracion", {}).get("output_csv"),
            "bateria_inicial": meta.get("bateria_inicial"),
            "bateria_final": meta.get("bateria_final"),
            "altura_inicial_real_cm": meta.get("altura_inicial_real_cm"),
            "altura_final_referencia_cm": meta.get("altura_final_referencia_cm"),
            "step_cm": meta.get("step_cm"),
        }
        row.update(meta.get("metricas_preliminares", {}))
        rows.append(row)

    summary = pd.DataFrame(rows)
    output = Path("datos") / f"{prefix}_resumen.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output, index=False, encoding="utf-8-sig")
    print(f"\nResumen de repetibilidad guardado en: {output}")
    return summary


def plot_repetition_comparison(dfs: list[pd.DataFrame], prefix: str) -> None:
    plt.figure(figsize=(9, 5))
    for idx, df in enumerate(dfs, start=1):
        if df.empty:
            continue
        t0 = float(df["tiempo"].iloc[0])
        plt.plot(df["tiempo"] - t0, df["altura"], linewidth=1.5, label=f"Rep {idx} — altura")

    # Se grafica una referencia representativa usando la primera repetición.
    if dfs and not dfs[0].empty:
        ref_df = dfs[0]
        plt.plot(
            ref_df["tiempo"] - float(ref_df["tiempo"].iloc[0]),
            ref_df["referencia"],
            "--",
            linewidth=1.2,
            label="Referencia rep. 1",
        )

    plt.grid(True)
    plt.xlabel("Tiempo relativo [s]")
    plt.ylabel("Altura [m]")
    plt.title("Equipo 1 — Repetibilidad experimental: comparación de repeticiones")
    plt.legend(loc="best")
    plt.tight_layout()

    output = Path("salidas") / f"{prefix}_comparacion.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=200)
    plt.close()
    print(f"Gráfica comparativa guardada en: {output}")


def run_repetibility_experiment(mock: bool, repetitions: int, base_config: ExperimentConfig, prefix: str) -> None:
    if repetitions < 1:
        raise ValueError("El número de repeticiones debe ser al menos 1.")

    print("\n" + "#" * 72)
    print(MISSION_NAME)
    print(MISSION_QUESTION)
    print("#" * 72)
    print("Se ejecutará el mismo escalón relativo en cada repetición:")
    print(f"    h0_real -> h0_real + {base_config.step_cm} cm")
    print("Cada repetición genera su propio CSV, metadatos y gráfica.")

    dfs: list[pd.DataFrame] = []
    metadatas: list[dict[str, Any]] = []

    for rep in range(1, repetitions + 1):
        cfg = build_rep_config(base_config, rep, prefix)
        df, meta = run_single_repetition(rep, repetitions, mock, cfg)
        dfs.append(df)
        metadatas.append(meta)

        if rep < repetitions:
            input("\nRevisa batería/zona de vuelo. Presiona ENTER para iniciar la siguiente repetición...")

    save_repetition_summary(metadatas, prefix)
    plot_repetition_comparison(dfs, prefix)

    print("\nExperimento diferenciado de repetibilidad completado.")
    print("Archivos clave:")
    print(f"  - datos/{prefix}_030cm_rep01.csv ... rep{repetitions:02d}.csv")
    print(f"  - datos/{prefix}_resumen.csv")
    print(f"  - salidas/{prefix}_comparacion.png")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Equipo 1 — Repetibilidad experimental con Tello.")
    parser.add_argument("--mock", action="store_true", help="Ejecuta simulación sin dron real.")
    parser.add_argument("--repetitions", type=int, default=3, help="Número de repeticiones. Recomendado: 3.")
    parser.add_argument("--step-cm", type=int, default=30, help="Magnitud del escalón relativo en cm. Recomendado: 30.")
    parser.add_argument("--sample-period", type=float, default=0.10, help="Periodo de muestreo en segundos. Recomendado: 0.10.")
    parser.add_argument("--initial-hold", type=float, default=3.0, help="Tiempo antes del escalón, en segundos.")
    parser.add_argument("--after-hold", type=float, default=8.0, help="Tiempo después del escalón, en segundos.")
    parser.add_argument("--prefix", default="equipo01_repetibilidad", help="Prefijo de archivos de salida.")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = ExperimentConfig(
        step_cm=args.step_cm,
        sample_period_s=args.sample_period,
        initial_hold_s=args.initial_hold,
        after_step_hold_s=args.after_hold,
    )

    try:
        run_repetibility_experiment(
            mock=args.mock,
            repetitions=args.repetitions,
            base_config=cfg,
            prefix=args.prefix,
        )
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR GENERAL] {exc}")
        sys.exit(1)
