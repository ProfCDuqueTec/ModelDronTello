from djitellopy import Tello
import time


def main():
    tello = Tello()

    try:
        tello.connect()

        battery = tello.get_battery()
        print(f"Batería: {battery} %")

        if battery < 30:
            print("Batería insuficiente para prueba de vuelo. Cargar batería.")
            return

        print("Despegando...")
        tello.takeoff()

        time.sleep(3)

        print(f"Altura durante vuelo: {tello.get_height()} cm")

        print("Aterrizando...")
        tello.land()

    except Exception as e:
        print("Error durante la prueba de vuelo.")
        print(e)

        try:
            tello.land()
        except Exception:
            pass

    finally:
        tello.end()


if __name__ == "__main__":
    main()
