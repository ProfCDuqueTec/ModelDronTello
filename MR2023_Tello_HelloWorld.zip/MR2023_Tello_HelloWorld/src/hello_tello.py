from djitellopy import Tello
from datetime import datetime
import pandas as pd
import time
from pathlib import Path


def main():
    print("MR2023 - Hello World con Tello")
    print("Inicializando comunicación con el dron...")

    tello = Tello()

    try:
        tello.connect()
        print("Conexión establecida correctamente.")

        battery = tello.get_battery()
        height = tello.get_height()
        temperature = tello.get_temperature()

        print(f"Batería: {battery} %")
        print(f"Altura reportada: {height} cm")
        print(f"Temperatura: {temperature} °C")

        print("\nRegistrando datos de altura durante 5 segundos...")
        registros = []

        start_time = time.time()

        while time.time() - start_time <= 5:
            t = time.time() - start_time
            h = tello.get_height()
            b = tello.get_battery()

            registros.append({
                "tiempo_s": t,
                "altura_cm": h,
                "bateria_pct": b
            })

            print(f"t = {t:.2f} s | h = {h} cm | batería = {b} %")
            time.sleep(0.5)

        output_dir = Path("data")
        output_dir.mkdir(exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = output_dir / f"hello_tello_log_{timestamp}.csv"

        df = pd.DataFrame(registros)
        df.to_csv(output_file, index=False)

        print(f"\nArchivo guardado correctamente en: {output_file}")

    except Exception as e:
        print("\nOcurrió un error de comunicación.")
        print("Revisar conexión Wi-Fi, batería del dron y que no haya otro programa usando el Tello.")
        print(f"Detalle técnico: {e}")

    finally:
        try:
            tello.end()
            print("Comunicación cerrada correctamente.")
        except Exception:
            pass


if __name__ == "__main__":
    main()
