import pandas as pd
import matplotlib

matplotlib.use("Agg")  # Evita abrir ventana con Tkinter

import matplotlib.pyplot as plt
from pathlib import Path

archivo = "data/hello_tello_log_20260531_101421.csv"

data = pd.read_csv(archivo)

plt.figure()
plt.plot(data["tiempo_s"], data["altura_cm"], marker="o")
plt.grid(True)
plt.xlabel("Tiempo [s]")
plt.ylabel("Altura [cm]")
plt.title("Hello World: lectura inicial de altura del Tello")

output_dir = Path("figures")
output_dir.mkdir(exist_ok=True)

plt.savefig("figures/grafica_altura_hello_tello.png", dpi=300, bbox_inches="tight")
plt.close()

print("Gráfica guardada en: figures/grafica_altura_hello_tello.png")