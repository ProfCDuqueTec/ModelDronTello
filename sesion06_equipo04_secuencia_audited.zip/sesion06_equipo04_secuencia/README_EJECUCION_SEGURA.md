# Ejecución segura — sesion06_equipo04_secuencia

Este paquete incluye el archivo base `src/experimento_patron_tello_v3.py`, necesario para que el experimento diferenciado funcione.

## Preparación

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Prueba sin dron

```bash
python src/experimento_secuencia_equipo04.py --mock
```

## Ejecución con dron

```bash
python src/experimento_secuencia_equipo04.py
```

## Parámetros recomendados

- Periodo de muestreo: `0.10 s`.
- Batería mínima: `35 %`.
- Altura máxima de clase: `150 cm`.
- No modificar amplitudes durante la sesión salvo autorización del profesor.

## Revisión antes de volar

1. Zona despejada.
2. Batería suficiente.
3. Dron en superficie estable.
4. Wi-Fi conectado al Tello.
5. Ejecutar primero modo `--mock`.
6. Profesor autoriza antes de presionar ENTER para despegar.
