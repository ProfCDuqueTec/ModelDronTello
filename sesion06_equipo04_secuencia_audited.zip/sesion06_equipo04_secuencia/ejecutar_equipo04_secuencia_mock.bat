@echo off
python src/experimento_secuencia_equipo04.py --mock
pause
