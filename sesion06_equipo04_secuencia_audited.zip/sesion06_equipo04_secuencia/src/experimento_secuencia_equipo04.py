"""
Sesión 6 — Bloque 5: Equipo 4, Secuencia de escalones
MR2023 Modelación para Automatización

Extensión mínima de experimento_patron_tello_v3.py.

Objetivo didáctico:
    Ejecutar una secuencia corta de dos escalones relativos en un mismo vuelo:

        h0_real -> h0_real + 30 cm -> h0_real + 50 cm

    y generar evidencia para responder:

        ¿Cómo responde el dron ante cambios consecutivos de referencia?

Decisión de seguridad y didáctica:
    Se usa una secuencia de dos escalones, no tres. Esto reduce riesgo operativo,
    mantiene baja la fricción técnica y permite analizar por tramos.

Uso recomendado con dron real:
    python src/experimento_secuencia_equipo04.py

Uso sin dron para prueba del flujo:
    python src/experimento_secuencia_equipo04.py --mock

Salidas principales:
    datos/equipo04_secuencia_escalones.csv
    datos/equipo04_secuencia_escalones_metadata.json
    datos/equipo04_secuencia_escalones_resumen.csv
    salidas/equipo04_secuencia_escalones.png
    salidas/equipo04_secuencia_escalones_tramos.png
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from experimento_patron_tello_v3 import (
    ExperimentConfig,
    TelemetryRecorder,
    create_drone,
    ensure_output_dirs,
    median_height_cm,
    plot_results,
    print_quality_check,
    safe_get_battery,
    safe_land,
    save_results,
    validate_config_for_real_drone,
)


MISSION_NAME = "Equipo 4 — Secuencia de escalones"
MISSION_QUESTION = "¿Cómo responde el dron ante cambios consecutivos de referencia?"


def build_sequence_config(base: ExperimentConfig, prefix: str) -> ExperimentConfig:
    """Crea la configuración de salida sin cambiar la lógica base de v3."""
    return ExperimentConfig(
        step_cm=base.step_cm,
        initial_hold_s=base.initial_hold_s,
        after_step_hold_s=base.after_step_hold_s,
        sample_period_s=base.sample_period_s,
        min_battery_percent=base.min_battery_percent,
        max_allowed_final_height_cm=base.max_allowed_final_height_cm,
        min_allowed_initial_height_cm=base.min_allowed_initial_height_cm,
        max_allowed_initial_height_cm=base.max_allowed_initial_height_cm,
        takeoff_settle_s=base.takeoff_settle_s,
        command_speed_cm_s=base.command_speed_cm_s,
        output_csv=f"datos/{prefix}.csv",
        output_plot=f"salidas/{prefix}.png",
        output_metadata=f"datos/{prefix}_metadata.json",
    )


def _segment_metrics(df: pd.DataFrame, segment_id: int, phase_before: str, phase_during: str, phase_after: str, step_cm: int) -> dict[str, float | str]:
    """Calcula métricas preliminares por tramo de escalón.

    Es una versión deliberadamente sencilla del cálculo del Bloque 3:
    h0, hf, K preliminar, tau por 63 %, sobreimpulso y RMS contra referencia.
    """
    if df.empty:
        return {"segmento": segment_id, "estado": "sin_datos"}

    before = df[df["fase"] == phase_before] if "fase" in df.columns else pd.DataFrame()
    during = df[df["fase"] == phase_during] if "fase" in df.columns else pd.DataFrame()
    after = df[df["fase"] == phase_after] if "fase" in df.columns else pd.DataFrame()

    if before.empty:
        # Si no hay fase antes explícita, usar muestras previas al comando.
        t_start_guess = float(during["tiempo"].min()) if not during.empty else float(df["tiempo"].iloc[0])
        before = df[df["tiempo"] < t_start_guess].tail(10)
    if after.empty:
        after = df.tail(10)

    h0 = float(before["altura"].tail(10).median()) if not before.empty else float("nan")
    hf = float(after["altura"].tail(10).mean()) if not after.empty else float("nan")
    delta_h = hf - h0
    delta_r = step_cm / 100.0
    k_est = delta_h / delta_r if delta_r != 0 else float("nan")

    t_start = float(during["tiempo"].min()) if not during.empty else float("nan")
    t_end = float(after["tiempo"].max()) if not after.empty else float("nan")
    h63 = h0 + 0.632 * delta_h if not math.isnan(delta_h) else float("nan")

    tau = float("nan")
    t63 = float("nan")
    if not math.isnan(t_start) and delta_h > 0:
        post = df[(df["tiempo"] >= t_start) & (df["tiempo"] <= t_end)].copy()
        reached = post[post["altura"] >= h63]
        if not reached.empty:
            t63 = float(reached["tiempo"].iloc[0])
            tau = t63 - t_start

    window = df[(df["tiempo"] >= t_start) & (df["tiempo"] <= t_end)].copy() if not math.isnan(t_start) else df.copy()
    overshoot_m = float(window["altura"].max() - hf) if not window.empty and not math.isnan(hf) else float("nan")
    overshoot_pct = float((overshoot_m / delta_h) * 100.0) if delta_h > 0 else float("nan")
    rms_to_reference = float(math.sqrt(((window["altura"] - window["referencia"]) ** 2).mean())) if not window.empty else float("nan")

    return {
        "segmento": float(segment_id),
        "step_cm": float(step_cm),
        "fase_antes": phase_before,
        "fase_comando": phase_during,
        "fase_despues": phase_after,
        "h0_m": h0,
        "hf_m": hf,
        "delta_h_m": delta_h,
        "delta_r_m": delta_r,
        "K_preliminar": k_est,
        "h63_m": h63,
        "t_inicio_escalon_s": t_start,
        "t63_s": t63,
        "tau_preliminar_s": tau,
        "sobreimpulso_aprox_m": overshoot_m,
        "sobreimpulso_aprox_pct": overshoot_pct,
        "rms_altura_vs_referencia_m": rms_to_reference,
        "muestras_tramo": float(len(window)),
    }


def estimate_sequence_metrics(df: pd.DataFrame, steps_cm: list[int]) -> pd.DataFrame:
    """Calcula métricas simples para los dos tramos de la secuencia."""
    rows: list[dict[str, float | str]] = []
    if len(steps_cm) >= 1:
        rows.append(_segment_metrics(
            df,
            segment_id=1,
            phase_before="antes_escalon_1",
            phase_during="durante_comando_up_1",
            phase_after="entre_escalones",
            step_cm=steps_cm[0],
        ))
    if len(steps_cm) >= 2:
        rows.append(_segment_metrics(
            df,
            segment_id=2,
            phase_before="entre_escalones",
            phase_during="durante_comando_up_2",
            phase_after="despues_escalon_2",
            step_cm=steps_cm[1],
        ))
    return pd.DataFrame(rows)


def plot_sequence_segments(df: pd.DataFrame, metadata: dict[str, Any], prefix: str) -> None:
    """Genera una gráfica con marcadores de aplicación de cada escalón."""
    if df.empty:
        return

    plt.figure(figsize=(9, 5))
    plt.plot(df["tiempo"], df["referencia"], "--", linewidth=1.2, label="Referencia")
    plt.plot(df["tiempo"], df["altura"], linewidth=1.6, label="Altura medida")

    for key, label in [
        ("tiempo_aplicacion_escalon_1_s", "Escalón 1"),
        ("tiempo_aplicacion_escalon_2_s", "Escalón 2"),
    ]:
        if key in metadata:
            plt.axvline(float(metadata[key]), linestyle=":", linewidth=1.2, label=label)

    plt.grid(True)
    plt.xlabel("Tiempo [s]")
    plt.ylabel("Altura [m]")
    plt.title("Equipo 4 — Secuencia de escalones")
    plt.legend(loc="best")
    plt.tight_layout()

    output = Path("salidas") / f"{prefix}_tramos.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=200)
    plt.close()
    print(f"Gráfica por tramos guardada en: {output}")


def run_sequence_experiment(mock: bool, steps_cm: list[int], hold_between_s: float, config: ExperimentConfig, prefix: str) -> None:
    """Ejecuta una secuencia de dos escalones en un solo vuelo."""
    if len(steps_cm) != 2:
        raise ValueError("Para esta misión didáctica se usan exactamente dos escalones. Recomendado: 30,20.")

    validate_config_for_real_drone(config, mock)
    ensure_output_dirs(config)

    drone = create_drone(mock)
    metadata: dict[str, Any] = {
        "curso": "MR2023 Modelación para Automatización",
        "sesion": "Sesión 6",
        "bloque": "Bloque 5 — Campaña experimental por equipos",
        "equipo": 4,
        "mision": MISSION_NAME,
        "pregunta_investigacion": MISSION_QUESTION,
        "experimento": "Secuencia corta de dos escalones relativos ascendentes",
        "steps_cm": steps_cm,
        "hold_between_s": hold_between_s,
        "configuracion": asdict(config),
        "modo_mock": mock,
        "timestamp_inicio": time.strftime("%Y-%m-%d %H:%M:%S"),
        "nota": (
            "Extensión mínima de v3. Se usa h0 real estable y una secuencia de dos escalones "
            "para estudiar la respuesta ante cambios consecutivos sin forzar alturas absolutas."
        ),
    }

    airborne = False
    recorder: TelemetryRecorder | None = None

    try:
        print("\n" + "=" * 72)
        print(MISSION_NAME)
        print(MISSION_QUESTION)
        print("=" * 72)
        print("Secuencia planificada:")
        print(f"    h0_real -> h0_real + {steps_cm[0]} cm -> h0_real + {sum(steps_cm)} cm")
        print("Conectando con el dron...")

        drone.connect()
        battery = safe_get_battery(drone)
        metadata["bateria_inicial"] = battery
        print(f"Batería inicial: {battery:.0f} %")

        if not mock and battery < config.min_battery_percent:
            raise RuntimeError(f"Batería insuficiente. Se recomienda al menos {config.min_battery_percent} %.")

        input("\nVerifica zona despejada y autorización del profesor. Presiona ENTER para despegar...")

        print("Despegando...")
        drone.takeoff()
        airborne = True
        time.sleep(config.takeoff_settle_s)

        try:
            drone.set_speed(config.command_speed_cm_s)
            print(f"Velocidad de comando configurada: {config.command_speed_cm_s} cm/s")
        except Exception as exc:  # noqa: BLE001
            print(f"[ADVERTENCIA] No se pudo configurar velocidad: {exc}")

        h0_cm = median_height_cm(drone, n=9, sample_period_s=0.08)
        if math.isnan(h0_cm):
            raise RuntimeError("No se pudo medir la altura inicial estable.")

        h0_cm = float(round(h0_cm))
        h1_cm = h0_cm + steps_cm[0]
        h2_cm = h1_cm + steps_cm[1]

        print("\nCondición inicial aceptada sin ajuste automático de altura")
        print(f"Altura inicial real medida: {h0_cm:.0f} cm")
        print(f"Escalón 1: +{steps_cm[0]} cm -> referencia {h1_cm:.0f} cm")
        print(f"Escalón 2: +{steps_cm[1]} cm -> referencia {h2_cm:.0f} cm")
        print(f"Muestreo objetivo: {1/config.sample_period_s:.1f} Hz")

        if h0_cm < config.min_allowed_initial_height_cm or h0_cm > config.max_allowed_initial_height_cm:
            raise RuntimeError(
                f"Altura inicial fuera de rango seguro: {h0_cm:.0f} cm. "
                f"Rango recomendado: {config.min_allowed_initial_height_cm}–{config.max_allowed_initial_height_cm} cm."
            )

        if h2_cm > config.max_allowed_final_height_cm:
            raise RuntimeError(
                f"La altura final estimada sería {h2_cm:.0f} cm, mayor que el límite de clase "
                f"({config.max_allowed_final_height_cm} cm). Reduce la secuencia de escalones."
            )

        metadata["altura_inicial_real_cm"] = h0_cm
        metadata["referencia_intermedia_cm"] = h1_cm
        metadata["altura_final_referencia_cm"] = h2_cm

        recorder = TelemetryRecorder(drone=drone, config=config)
        recorder.set_state(phase="antes_escalon_1", reference_cm=h0_cm)
        recorder.start()

        time.sleep(config.initial_hold_s)

        print(f"\nAplicando escalón 1: move_up({steps_cm[0]} cm)...")
        metadata["tiempo_aplicacion_escalon_1_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_up_1", reference_cm=h1_cm)
        drone.move_up(steps_cm[0])
        metadata["tiempo_fin_comando_1_s"] = recorder.elapsed()
        metadata["duracion_comando_1_s"] = metadata["tiempo_fin_comando_1_s"] - metadata["tiempo_aplicacion_escalon_1_s"]

        print(f"Manteniendo referencia intermedia durante {hold_between_s:.1f} s...")
        recorder.set_state(phase="entre_escalones", reference_cm=h1_cm)
        time.sleep(hold_between_s)

        print(f"\nAplicando escalón 2: move_up({steps_cm[1]} cm)...")
        metadata["tiempo_aplicacion_escalon_2_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_up_2", reference_cm=h2_cm)
        drone.move_up(steps_cm[1])
        metadata["tiempo_fin_comando_2_s"] = recorder.elapsed()
        metadata["duracion_comando_2_s"] = metadata["tiempo_fin_comando_2_s"] - metadata["tiempo_aplicacion_escalon_2_s"]

        recorder.set_state(phase="despues_escalon_2", reference_cm=h2_cm)
        time.sleep(config.after_step_hold_s)
        recorder.stop()

        print("\nAterrizando...")
        aterrizo_ok = safe_land(drone)
        airborne = False
        if not aterrizo_ok:
            raise RuntimeError("El aterrizaje automático falló. Revisar dron antes de repetir la práctica.")

        metadata["timestamp_fin"] = time.strftime("%Y-%m-%d %H:%M:%S")
        metadata["bateria_final"] = safe_get_battery(drone)

        df = save_results(recorder.samples, config, metadata)
        plot_results(df, config)
        print_quality_check(df)

        metrics_df = estimate_sequence_metrics(df, steps_cm)
        summary_path = Path("datos") / f"{prefix}_resumen.csv"
        summary_path.parent.mkdir(parents=True, exist_ok=True)
        metrics_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
        print(f"Resumen por tramos guardado en: {summary_path}")

        metadata["metricas_preliminares_por_tramo"] = metrics_df.to_dict(orient="records")
        with open(config.output_metadata, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=4, ensure_ascii=False)

        plot_sequence_segments(df, metadata, prefix)

        print("\nExperimento de secuencia de escalones completado correctamente.")
        print("Archivos clave:")
        print(f"  - {config.output_csv}")
        print(f"  - {config.output_metadata}")
        print(f"  - {summary_path}")
        print(f"  - {config.output_plot}")
        print(f"  - salidas/{prefix}_tramos.png")

    except KeyboardInterrupt:
        print("\nInterrupción manual detectada.")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando aterrizar por seguridad...")
            safe_land(drone)
        raise

    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR] Secuencia de escalones: {exc}")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando estabilizar y aterrizar por seguridad...")
            safe_land(drone)
        raise

    finally:
        try:
            if hasattr(drone, "is_flying") and not getattr(drone, "is_flying"):
                drone.end()
            elif not airborne:
                drone.end()
        except Exception:
            pass


def parse_steps(raw: str) -> list[int]:
    try:
        steps = [int(x.strip()) for x in raw.split(",") if x.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Usa dos enteros separados por coma, por ejemplo: 30,20") from exc

    if len(steps) != 2:
        raise argparse.ArgumentTypeError("Para esta misión usa exactamente dos escalones, por ejemplo: 30,20")
    if any(step < 20 for step in steps):
        raise argparse.ArgumentTypeError("El SDK del Tello requiere movimientos de al menos 20 cm.")
    if sum(steps) > 60:
        raise argparse.ArgumentTypeError("Para clase se recomienda que el ascenso acumulado no exceda 60 cm.")
    return steps


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Equipo 4 — Secuencia de escalones con Tello.")
    parser.add_argument("--mock", action="store_true", help="Ejecuta simulación sin dron real.")
    parser.add_argument("--steps-cm", type=parse_steps, default=[30, 20], help="Dos incrementos en cm separados por coma. Recomendado: 30,20.")
    parser.add_argument("--sample-period", type=float, default=0.10, help="Periodo de muestreo en segundos. Recomendado: 0.10.")
    parser.add_argument("--initial-hold", type=float, default=3.0, help="Tiempo antes del primer escalón, en segundos.")
    parser.add_argument("--between-hold", type=float, default=5.0, help="Tiempo entre escalones, en segundos. Recomendado: 5.")
    parser.add_argument("--after-hold", type=float, default=8.0, help="Tiempo después del segundo escalón, en segundos.")
    parser.add_argument("--prefix", default="equipo04_secuencia_escalones", help="Prefijo de archivos de salida.")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = ExperimentConfig(
        step_cm=args.steps_cm[0],  # valor base; la secuencia usa steps_cm.
        sample_period_s=args.sample_period,
        initial_hold_s=args.initial_hold,
        after_step_hold_s=args.after_hold,
    )
    cfg = build_sequence_config(cfg, args.prefix)

    try:
        run_sequence_experiment(
            mock=args.mock,
            steps_cm=args.steps_cm,
            hold_between_s=args.between_hold,
            config=cfg,
            prefix=args.prefix,
        )
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR GENERAL] {exc}")
        sys.exit(1)
