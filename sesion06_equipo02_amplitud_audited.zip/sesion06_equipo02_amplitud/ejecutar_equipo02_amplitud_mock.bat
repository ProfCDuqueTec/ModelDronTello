@echo off
python src/experimento_amplitud_equipo02.py --mock
pause
