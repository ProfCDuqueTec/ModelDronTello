"""
Sesión 6 — Bloque 5: Equipo 2, Efecto de amplitud
MR2023 Modelación para Automatización

Extensión mínima de experimento_patron_tello_v3.py.

Objetivo didáctico:
    Ejecutar dos escalones verticales relativos de distinta magnitud:

        Prueba A: h0_real -> h0_real + 30 cm
        Prueba B: h0_real -> h0_real + 40 cm

    y generar evidencia para responder:

        ¿La magnitud del cambio modifica la respuesta dinámica observada?

Uso recomendado con dron real:
    python src/experimento_amplitud_equipo02.py

Uso sin dron para prueba del flujo:
    python src/experimento_amplitud_equipo02.py --mock

Salidas principales:
    datos/equipo02_amplitud_020cm.csv
    datos/equipo02_amplitud_040cm.csv
    datos/equipo02_amplitud_resumen.csv
    salidas/equipo02_amplitud_comparacion.png
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from experimento_patron_tello_v3 import (
    ExperimentConfig,
    TelemetryRecorder,
    create_drone,
    ensure_output_dirs,
    median_height_cm,
    plot_results,
    print_quality_check,
    safe_get_battery,
    safe_land,
    save_results,
    validate_config_for_real_drone,
)


MISSION_NAME = "Equipo 2 — Efecto de amplitud"
MISSION_QUESTION = "¿La magnitud del cambio modifica la respuesta dinámica observada?"


def build_step_config(base: ExperimentConfig, step_cm: int, prefix: str) -> ExperimentConfig:
    """Crea una configuración de salida para una amplitud específica sin cambiar la lógica v3."""
    step_tag = f"{step_cm:03d}cm"
    stem = f"{prefix}_{step_tag}"
    return ExperimentConfig(
        step_cm=step_cm,
        initial_hold_s=base.initial_hold_s,
        after_step_hold_s=base.after_step_hold_s,
        sample_period_s=base.sample_period_s,
        min_battery_percent=base.min_battery_percent,
        max_allowed_final_height_cm=base.max_allowed_final_height_cm,
        min_allowed_initial_height_cm=base.min_allowed_initial_height_cm,
        max_allowed_initial_height_cm=base.max_allowed_initial_height_cm,
        takeoff_settle_s=base.takeoff_settle_s,
        command_speed_cm_s=base.command_speed_cm_s,
        output_csv=f"datos/{stem}.csv",
        output_plot=f"salidas/{stem}.png",
        output_metadata=f"datos/{stem}_metadata.json",
    )


def estimate_basic_metrics(df: pd.DataFrame, step_cm: int) -> dict[str, float]:
    """Calcula métricas preliminares de cada amplitud para comparación rápida.

    No sustituye el análisis formal de la tarea; solo permite validar si las curvas son útiles.
    """
    if df.empty:
        return {}

    before = df[df["fase"] == "antes_del_escalon"] if "fase" in df.columns else pd.DataFrame()
    after = df[df["fase"] == "despues_del_escalon"] if "fase" in df.columns else pd.DataFrame()
    during = df[df["fase"] == "durante_comando_up"] if "fase" in df.columns else pd.DataFrame()

    h0 = float(before["altura"].median()) if not before.empty else float(df["altura"].iloc[:10].mean())
    hf = float(after["altura"].tail(10).mean()) if not after.empty else float(df["altura"].iloc[-10:].mean())
    delta_h = hf - h0
    delta_r = step_cm / 100.0
    k_est = delta_h / delta_r if delta_r != 0 else float("nan")

    t_start = float(during["tiempo"].min()) if not during.empty else float(df["tiempo"].iloc[0])
    h63 = h0 + 0.632 * delta_h
    post = df[df["tiempo"] >= t_start].copy()

    tau = float("nan")
    t63 = float("nan")
    if not post.empty and delta_h > 0:
        reached = post[post["altura"] >= h63]
        if not reached.empty:
            t63 = float(reached["tiempo"].iloc[0])
            tau = t63 - t_start

    overshoot_m = float(df["altura"].max() - hf)
    overshoot_pct = float((overshoot_m / delta_h) * 100.0) if delta_h > 0 else float("nan")
    rms_to_reference = float(math.sqrt(((df["altura"] - df["referencia"]) ** 2).mean()))

    return {
        "step_cm": float(step_cm),
        "h0_m": h0,
        "hf_m": hf,
        "delta_h_m": delta_h,
        "delta_r_m": delta_r,
        "K_preliminar": k_est,
        "h63_m": h63,
        "t_inicio_escalon_s": t_start,
        "t63_s": t63,
        "tau_preliminar_s": tau,
        "sobreimpulso_aprox_m": overshoot_m,
        "sobreimpulso_aprox_pct": overshoot_pct,
        "rms_altura_vs_referencia_m": rms_to_reference,
        "muestras": float(len(df)),
        "duracion_s": float(df["tiempo"].max() - df["tiempo"].min()),
    }


def run_single_amplitude(test_index: int, total_tests: int, step_cm: int, mock: bool, config: ExperimentConfig) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Ejecuta una prueba completa de amplitud: conectar, despegar, registrar, aplicar escalón, aterrizar y guardar."""
    validate_config_for_real_drone(config, mock)
    ensure_output_dirs(config)

    drone = create_drone(mock)
    metadata: dict[str, Any] = {
        "curso": "MR2023 Modelación para Automatización",
        "sesion": "Sesión 6",
        "bloque": "Bloque 5 — Campaña experimental por equipos",
        "equipo": 2,
        "mision": MISSION_NAME,
        "pregunta_investigacion": MISSION_QUESTION,
        "prueba": test_index,
        "total_pruebas": total_tests,
        "step_cm": step_cm,
        "experimento": "Escalón relativo ascendente para evaluar efecto de amplitud",
        "configuracion": asdict(config),
        "modo_mock": mock,
        "timestamp_inicio": time.strftime("%Y-%m-%d %H:%M:%S"),
        "nota": (
            "Extensión mínima de v3. Se usa h0 real estable y se comparan escalones relativos "
            "moderados de distinta amplitud para evaluar sobreimpulso, rapidez y validez del modelo de primer orden."
        ),
    }

    airborne = False
    recorder: TelemetryRecorder | None = None

    try:
        print("\n" + "=" * 72)
        print(f"{MISSION_NAME} | Prueba {test_index}/{total_tests} | Escalón +{step_cm} cm")
        print("=" * 72)
        print("Conectando con el dron...")
        drone.connect()
        battery = safe_get_battery(drone)
        metadata["bateria_inicial"] = battery
        print(f"Batería inicial: {battery:.0f} %")

        if not mock and battery < config.min_battery_percent:
            raise RuntimeError(f"Batería insuficiente. Se recomienda al menos {config.min_battery_percent} %.")

        input("\nVerifica zona despejada y autorización del profesor. Presiona ENTER para despegar...")

        print("Despegando...")
        drone.takeoff()
        airborne = True
        time.sleep(config.takeoff_settle_s)

        try:
            drone.set_speed(config.command_speed_cm_s)
            print(f"Velocidad de comando configurada: {config.command_speed_cm_s} cm/s")
        except Exception as exc:  # noqa: BLE001
            print(f"[ADVERTENCIA] No se pudo configurar velocidad: {exc}")

        h0_cm = median_height_cm(drone, n=9, sample_period_s=0.08)
        if math.isnan(h0_cm):
            raise RuntimeError("No se pudo medir la altura inicial estable.")

        h0_cm = float(round(h0_cm))
        hf_cm = h0_cm + step_cm

        print("\nCondición inicial aceptada sin ajuste automático de altura")
        print(f"Altura inicial real medida: {h0_cm:.0f} cm")
        print(f"Escalón relativo aplicado: +{step_cm} cm")
        print(f"Referencia experimental: {h0_cm:.0f} cm -> {hf_cm:.0f} cm")
        print(f"Muestreo objetivo: {1/config.sample_period_s:.1f} Hz")

        if h0_cm < config.min_allowed_initial_height_cm or h0_cm > config.max_allowed_initial_height_cm:
            raise RuntimeError(
                f"Altura inicial fuera de rango seguro: {h0_cm:.0f} cm. "
                f"Rango recomendado: {config.min_allowed_initial_height_cm}–{config.max_allowed_initial_height_cm} cm."
            )

        if hf_cm > config.max_allowed_final_height_cm:
            raise RuntimeError(
                f"La altura final estimada sería {hf_cm:.0f} cm, mayor que el límite de clase "
                f"({config.max_allowed_final_height_cm} cm). Reduce la amplitud del escalón."
            )

        metadata["altura_inicial_real_cm"] = h0_cm
        metadata["altura_final_referencia_cm"] = hf_cm

        recorder = TelemetryRecorder(drone=drone, config=config)
        recorder.set_state(phase="antes_del_escalon", reference_cm=h0_cm)
        recorder.start()

        time.sleep(config.initial_hold_s)

        print(f"\nAplicando escalón de amplitud: move_up({step_cm} cm)...")
        metadata["tiempo_aplicacion_escalon_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_up", reference_cm=hf_cm)

        drone.move_up(step_cm)

        metadata["tiempo_fin_comando_s"] = recorder.elapsed()
        metadata["duracion_comando_s"] = metadata["tiempo_fin_comando_s"] - metadata["tiempo_aplicacion_escalon_s"]
        recorder.set_state(phase="despues_del_escalon", reference_cm=hf_cm)

        time.sleep(config.after_step_hold_s)
        recorder.stop()

        print("\nAterrizando...")
        aterrizo_ok = safe_land(drone)
        airborne = False
        if not aterrizo_ok:
            raise RuntimeError("El aterrizaje automático falló. Revisar dron antes de repetir la práctica.")

        metadata["timestamp_fin"] = time.strftime("%Y-%m-%d %H:%M:%S")
        metadata["bateria_final"] = safe_get_battery(drone)

        df = save_results(recorder.samples, config, metadata)
        plot_results(df, config)
        print_quality_check(df)

        metrics = estimate_basic_metrics(df, step_cm)
        metadata["metricas_preliminares"] = metrics
        with open(config.output_metadata, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=4, ensure_ascii=False)

        print(f"\nPrueba de amplitud +{step_cm} cm completada correctamente.")
        return df, metadata

    except KeyboardInterrupt:
        print("\nInterrupción manual detectada.")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando aterrizar por seguridad...")
            safe_land(drone)
        raise

    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR] Prueba +{step_cm} cm: {exc}")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando estabilizar y aterrizar por seguridad...")
            safe_land(drone)
        raise

    finally:
        try:
            if hasattr(drone, "is_flying") and not getattr(drone, "is_flying"):
                drone.end()
            elif not airborne:
                drone.end()
        except Exception:
            pass


def save_amplitude_summary(metadatas: list[dict[str, Any]], prefix: str) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for meta in metadatas:
        row: dict[str, Any] = {
            "prueba": meta.get("prueba"),
            "archivo_csv": meta.get("configuracion", {}).get("output_csv"),
            "bateria_inicial": meta.get("bateria_inicial"),
            "bateria_final": meta.get("bateria_final"),
            "altura_inicial_real_cm": meta.get("altura_inicial_real_cm"),
            "altura_final_referencia_cm": meta.get("altura_final_referencia_cm"),
            "step_cm": meta.get("step_cm"),
        }
        row.update(meta.get("metricas_preliminares", {}))
        rows.append(row)

    summary = pd.DataFrame(rows)

    # Comparaciones simples entre la amplitud menor y la mayor.
    if len(summary) >= 2:
        summary = summary.sort_values("step_cm").reset_index(drop=True)
        small = summary.iloc[0]
        large = summary.iloc[-1]
        comparison_rows = []
        for col in ["K_preliminar", "tau_preliminar_s", "sobreimpulso_aprox_m", "rms_altura_vs_referencia_m"]:
            try:
                comparison_rows.append({
                    "metrica": col,
                    "valor_escalon_menor": float(small[col]),
                    "valor_escalon_mayor": float(large[col]),
                    "diferencia_mayor_menos_menor": float(large[col]) - float(small[col]),
                })
            except Exception:
                pass
        comparison = pd.DataFrame(comparison_rows)
        comp_output = Path("datos") / f"{prefix}_comparacion_metricas.csv"
        comparison.to_csv(comp_output, index=False, encoding="utf-8-sig")
        print(f"Comparación de métricas guardada en: {comp_output}")

    output = Path("datos") / f"{prefix}_resumen.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output, index=False, encoding="utf-8-sig")
    print(f"\nResumen de amplitud guardado en: {output}")
    return summary


def plot_amplitude_comparison(dfs: list[pd.DataFrame], steps_cm: list[int], prefix: str) -> None:
    plt.figure(figsize=(9, 5))
    for df, step_cm in zip(dfs, steps_cm):
        if df.empty:
            continue
        t0 = float(df["tiempo"].iloc[0])
        plt.plot(df["tiempo"] - t0, df["altura"], linewidth=1.6, label=f"Altura +{step_cm} cm")
        plt.plot(df["tiempo"] - t0, df["referencia"], "--", linewidth=1.0, label=f"Referencia +{step_cm} cm")

    plt.grid(True)
    plt.xlabel("Tiempo relativo [s]")
    plt.ylabel("Altura [m]")
    plt.title("Equipo 2 — Efecto de amplitud: comparación de escalones")
    plt.legend(loc="best")
    plt.tight_layout()

    output = Path("salidas") / f"{prefix}_comparacion.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=200)
    plt.close()
    print(f"Gráfica comparativa guardada en: {output}")


def run_amplitude_experiment(mock: bool, steps_cm: list[int], base_config: ExperimentConfig, prefix: str) -> None:
    if not steps_cm:
        raise ValueError("Debes especificar al menos una amplitud de escalón.")

    print("\n" + "#" * 72)
    print(MISSION_NAME)
    print(MISSION_QUESTION)
    print("#" * 72)
    print("Se ejecutarán escalones relativos ascendentes de distinta magnitud:")
    for step_cm in steps_cm:
        print(f"    h0_real -> h0_real + {step_cm} cm")
    print("Cada amplitud genera su propio CSV, metadatos y gráfica.")

    dfs: list[pd.DataFrame] = []
    metadatas: list[dict[str, Any]] = []

    for idx, step_cm in enumerate(steps_cm, start=1):
        cfg = build_step_config(base_config, step_cm, prefix)
        df, meta = run_single_amplitude(idx, len(steps_cm), step_cm, mock, cfg)
        dfs.append(df)
        metadatas.append(meta)

        if idx < len(steps_cm):
            input("\nRevisa batería/zona de vuelo. Presiona ENTER para iniciar la siguiente amplitud...")

    save_amplitude_summary(metadatas, prefix)
    plot_amplitude_comparison(dfs, steps_cm, prefix)

    print("\nExperimento diferenciado de efecto de amplitud completado.")
    print("Archivos clave:")
    for step_cm in steps_cm:
        print(f"  - datos/{prefix}_{step_cm:03d}cm.csv")
    print(f"  - datos/{prefix}_resumen.csv")
    print(f"  - datos/{prefix}_comparacion_metricas.csv")
    print(f"  - salidas/{prefix}_comparacion.png")


def parse_steps(raw: str) -> list[int]:
    try:
        steps = [int(x.strip()) for x in raw.split(",") if x.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Usa enteros separados por coma, por ejemplo: 20,40") from exc

    if any(step < 20 for step in steps):
        raise argparse.ArgumentTypeError("El SDK del Tello requiere movimientos de al menos 20 cm.")
    if any(step > 50 for step in steps):
        raise argparse.ArgumentTypeError("Para clase se recomienda no exceder 50 cm por seguridad.")
    return steps


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Equipo 2 — Efecto de amplitud con Tello.")
    parser.add_argument("--mock", action="store_true", help="Ejecuta simulación sin dron real.")
    parser.add_argument("--steps-cm", type=parse_steps, default=[30, 40], help="Amplitudes en cm separadas por coma. Recomendado: 30,40.")
    parser.add_argument("--sample-period", type=float, default=0.10, help="Periodo de muestreo en segundos. Recomendado: 0.10.")
    parser.add_argument("--initial-hold", type=float, default=3.0, help="Tiempo antes del escalón, en segundos.")
    parser.add_argument("--after-hold", type=float, default=8.0, help="Tiempo después del escalón, en segundos.")
    parser.add_argument("--prefix", default="equipo02_amplitud", help="Prefijo de archivos de salida.")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = ExperimentConfig(
        step_cm=30,  # valor base; cada prueba lo reemplaza con --steps-cm
        sample_period_s=args.sample_period,
        initial_hold_s=args.initial_hold,
        after_step_hold_s=args.after_hold,
    )

    try:
        run_amplitude_experiment(
            mock=args.mock,
            steps_cm=args.steps_cm,
            base_config=cfg,
            prefix=args.prefix,
        )
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR GENERAL] {exc}")
        sys.exit(1)
