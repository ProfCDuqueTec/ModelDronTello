@echo off
python src/experimento_ascenso_descenso_equipo06.py --mock
pause
