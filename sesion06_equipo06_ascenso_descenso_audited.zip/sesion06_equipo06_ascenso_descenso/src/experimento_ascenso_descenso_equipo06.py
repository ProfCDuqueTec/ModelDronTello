"""
Sesión 6 — Bloque 5: Equipo 6, Ascenso-descenso
MR2023 Modelación para Automatización

Extensión mínima de experimento_patron_tello_v3.py.

Objetivo didáctico:
    Ejecutar una secuencia corta de inversión de referencia en un mismo vuelo:

        h0_real -> h0_real + 30 cm -> h0_real

    y generar evidencia para responder:

        ¿Qué ocurre cuando el sistema invierte la dirección de seguimiento de altura?

Decisión de seguridad y didáctica:
    Se usa un ascenso relativo y un descenso relativo de la misma magnitud. No se
    fuerzan alturas absolutas. El CSV contiene ambos tramos para analizar por separado.

Uso recomendado con dron real:
    python src/experimento_ascenso_descenso_equipo06.py

Uso sin dron para prueba del flujo:
    python src/experimento_ascenso_descenso_equipo06.py --mock

Salidas principales:
    datos/equipo06_ascenso_descenso_030cm.csv
    datos/equipo06_ascenso_descenso_030cm_metadata.json
    datos/equipo06_ascenso_descenso_resumen.csv
    salidas/equipo06_ascenso_descenso_030cm.png
    salidas/equipo06_ascenso_descenso_tramos.png
    salidas/equipo06_ascenso_descenso_desviacion.png
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from experimento_patron_tello_v3 import (
    ExperimentConfig,
    TelemetryRecorder,
    create_drone,
    ensure_output_dirs,
    median_height_cm,
    plot_results,
    print_quality_check,
    safe_get_battery,
    safe_land,
    save_results,
    validate_config_for_real_drone,
)


MISSION_NAME = "Equipo 6 — Ascenso-descenso"
MISSION_QUESTION = "¿Qué ocurre cuando el sistema invierte la dirección de seguimiento de altura?"


def build_ascent_descent_config(base: ExperimentConfig, step_cm: int, prefix: str) -> ExperimentConfig:
    """Crea nombres de salida específicos sin modificar la lógica base de v3."""
    stem = f"{prefix}_{step_cm:03d}cm"
    return ExperimentConfig(
        step_cm=step_cm,
        initial_hold_s=base.initial_hold_s,
        after_step_hold_s=base.after_step_hold_s,
        sample_period_s=base.sample_period_s,
        min_battery_percent=base.min_battery_percent,
        max_allowed_final_height_cm=base.max_allowed_final_height_cm,
        min_allowed_initial_height_cm=base.min_allowed_initial_height_cm,
        max_allowed_initial_height_cm=base.max_allowed_initial_height_cm,
        takeoff_settle_s=base.takeoff_settle_s,
        command_speed_cm_s=base.command_speed_cm_s,
        output_csv=f"datos/{stem}.csv",
        output_plot=f"salidas/{stem}.png",
        output_metadata=f"datos/{stem}_metadata.json",
    )


def move_down_compatible(drone: Any, cm: int) -> None:
    """Ejecuta descenso real; en mock simula move_down porque la v3 solo trae move_up."""
    if hasattr(drone, "move_down"):
        drone.move_down(cm)
        return

    print(f"[MOCK] Comando down {cm} cm.")
    current = float(drone.get_height()) if hasattr(drone, "get_height") else 100.0
    if hasattr(drone, "_step_start_height"):
        drone._step_start_height = current  # noqa: SLF001
    if hasattr(drone, "_step_target_height"):
        drone._step_target_height = current - cm  # noqa: SLF001
    if hasattr(drone, "_step_start_time"):
        drone._step_start_time = time.monotonic()  # noqa: SLF001
    time.sleep(2.8)


def _segment_metrics(
    df: pd.DataFrame,
    name: str,
    phase_before: str,
    phase_during: str,
    phase_after: str,
    delta_r_m: float,
) -> dict[str, float | str]:
    """Calcula métricas preliminares por tramo.

    Es deliberadamente sencillo y replica la lógica del Bloque 3:
    h0, hf, K preliminar, tau por 63 %, sobreimpulso/sobrepaso y RMS contra referencia.
    """
    if df.empty:
        return {"tramo": name, "estado": "sin_datos"}

    before = df[df["fase"] == phase_before] if "fase" in df.columns else pd.DataFrame()
    during = df[df["fase"] == phase_during] if "fase" in df.columns else pd.DataFrame()
    after = df[df["fase"] == phase_after] if "fase" in df.columns else pd.DataFrame()

    if before.empty:
        t_start_guess = float(during["tiempo"].min()) if not during.empty else float(df["tiempo"].iloc[0])
        before = df[df["tiempo"] < t_start_guess].tail(10)
    if after.empty:
        after = df.tail(10)

    h0 = float(before["altura"].tail(10).median()) if not before.empty else float("nan")
    hf = float(after["altura"].tail(10).mean()) if not after.empty else float("nan")
    delta_h = hf - h0
    k_est = delta_h / delta_r_m if abs(delta_r_m) > 1e-12 else float("nan")

    t_start = float(during["tiempo"].min()) if not during.empty else float("nan")
    t_end = float(after["tiempo"].max()) if not after.empty else float("nan")
    h63 = h0 + 0.632 * delta_h if not math.isnan(delta_h) else float("nan")

    tau = float("nan")
    t63 = float("nan")
    if not math.isnan(t_start):
        window = df[(df["tiempo"] >= t_start) & (df["tiempo"] <= t_end)].copy() if not math.isnan(t_end) else df[df["tiempo"] >= t_start].copy()
        if delta_h > 0:
            reached = window[window["altura"] >= h63]
        else:
            reached = window[window["altura"] <= h63]
        if not reached.empty:
            t63 = float(reached["tiempo"].iloc[0])
            tau = t63 - t_start
    else:
        window = df.copy()

    if delta_h >= 0:
        overshoot_m = float(window["altura"].max() - hf) if not window.empty and not math.isnan(hf) else float("nan")
        overshoot_pct = float((overshoot_m / abs(delta_h)) * 100.0) if abs(delta_h) > 1e-9 else float("nan")
        undershoot_m = float("nan")
        undershoot_pct = float("nan")
    else:
        undershoot_m = float(hf - window["altura"].min()) if not window.empty and not math.isnan(hf) else float("nan")
        undershoot_pct = float((undershoot_m / abs(delta_h)) * 100.0) if abs(delta_h) > 1e-9 else float("nan")
        overshoot_m = float("nan")
        overshoot_pct = float("nan")

    rms_to_reference = float(math.sqrt(((window["altura"] - window["referencia"]) ** 2).mean())) if not window.empty else float("nan")

    return {
        "tramo": name,
        "fase_antes": phase_before,
        "fase_comando": phase_during,
        "fase_despues": phase_after,
        "h0_m": h0,
        "hf_m": hf,
        "delta_h_m": delta_h,
        "delta_r_m": delta_r_m,
        "K_preliminar": k_est,
        "h63_m": h63,
        "t_inicio_escalon_s": t_start,
        "t63_s": t63,
        "tau_preliminar_s": tau,
        "sobreimpulso_aprox_m": overshoot_m,
        "sobreimpulso_aprox_pct": overshoot_pct,
        "sobrepaso_hacia_abajo_aprox_m": undershoot_m,
        "sobrepaso_hacia_abajo_aprox_pct": undershoot_pct,
        "rms_altura_vs_referencia_m": rms_to_reference,
        "muestras_tramo": float(len(window)),
    }


def estimate_ascent_descent_metrics(df: pd.DataFrame, step_cm: int) -> pd.DataFrame:
    """Calcula métricas simples para ascenso y descenso."""
    step_m = step_cm / 100.0
    rows = [
        _segment_metrics(
            df,
            name="ascenso",
            phase_before="antes_ascenso",
            phase_during="durante_comando_up",
            phase_after="arriba_estable",
            delta_r_m=step_m,
        ),
        _segment_metrics(
            df,
            name="descenso",
            phase_before="arriba_estable",
            phase_during="durante_comando_down",
            phase_after="despues_descenso",
            delta_r_m=-step_m,
        ),
    ]
    return pd.DataFrame(rows)


def plot_ascent_descent_segments(df: pd.DataFrame, metadata: dict[str, Any], prefix: str) -> None:
    """Genera gráfica con marcadores del ascenso y descenso."""
    if df.empty:
        return

    plt.figure(figsize=(9, 5))
    plt.plot(df["tiempo"], df["referencia"], "--", linewidth=1.2, label="Referencia")
    plt.plot(df["tiempo"], df["altura"], linewidth=1.6, label="Altura medida")

    for key, label in [
        ("tiempo_aplicacion_ascenso_s", "Ascenso"),
        ("tiempo_aplicacion_descenso_s", "Descenso"),
    ]:
        if key in metadata:
            plt.axvline(float(metadata[key]), linestyle=":", linewidth=1.2, label=label)

    plt.grid(True)
    plt.xlabel("Tiempo [s]")
    plt.ylabel("Altura [m]")
    plt.title("Equipo 6 — Ascenso-descenso")
    plt.legend(loc="best")
    plt.tight_layout()

    output = Path("salidas") / f"{prefix}_tramos.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=200)
    plt.close()
    print(f"Gráfica por tramos guardada en: {output}")


def plot_deviation_comparison(df: pd.DataFrame, metadata: dict[str, Any], prefix: str) -> None:
    """Compara ascenso y descenso en variables de desviación.

    Para el descenso se grafica la magnitud descendida positiva: h0_descenso - h(t),
    de modo que se pueda comparar contra el ascenso h(t) - h0_ascenso.
    """
    if df.empty or "fase" not in df.columns:
        return

    try:
        t_up = float(metadata["tiempo_aplicacion_ascenso_s"])
        t_down = float(metadata["tiempo_aplicacion_descenso_s"])
    except KeyError:
        return

    up = df[(df["tiempo"] >= t_up) & (df["tiempo"] < t_down)].copy()
    down = df[df["tiempo"] >= t_down].copy()
    if up.empty or down.empty:
        return

    h0_up = float(up["altura"].iloc[0])
    h0_down = float(down["altura"].iloc[0])

    plt.figure(figsize=(9, 5))
    plt.plot(up["tiempo"] - t_up, up["altura"] - h0_up, linewidth=1.6, label="Ascenso: h(t)-h0")
    plt.plot(down["tiempo"] - t_down, h0_down - down["altura"], linewidth=1.6, label="Descenso: h0-h(t)")
    plt.grid(True)
    plt.xlabel("Tiempo desde el comando [s]")
    plt.ylabel("Cambio de altura medido [m]")
    plt.title("Equipo 6 — Comparación en variables de desviación")
    plt.legend(loc="best")
    plt.tight_layout()

    output = Path("salidas") / f"{prefix}_desviacion.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=200)
    plt.close()
    print(f"Gráfica en variables de desviación guardada en: {output}")


def run_ascent_descent_experiment(mock: bool, config: ExperimentConfig, hold_high_s: float, prefix: str) -> None:
    """Ejecuta ascenso-descenso en un solo vuelo."""
    validate_config_for_real_drone(config, mock)
    ensure_output_dirs(config)

    drone = create_drone(mock)
    metadata: dict[str, Any] = {
        "curso": "MR2023 Modelación para Automatización",
        "sesion": "Sesión 6",
        "bloque": "Bloque 5 — Campaña experimental por equipos",
        "equipo": 6,
        "mision": MISSION_NAME,
        "pregunta_investigacion": MISSION_QUESTION,
        "experimento": "Ascenso relativo seguido de descenso relativo en el mismo vuelo",
        "step_cm": config.step_cm,
        "hold_high_s": hold_high_s,
        "configuracion": asdict(config),
        "modo_mock": mock,
        "timestamp_inicio": time.strftime("%Y-%m-%d %H:%M:%S"),
        "nota": (
            "Extensión mínima de v3. Se usa h0 real estable y una inversión de referencia "
            "h0 -> h0 + step_cm -> h0, sin forzar alturas absolutas."
        ),
    }

    airborne = False
    recorder: TelemetryRecorder | None = None

    try:
        print("\n" + "=" * 72)
        print(MISSION_NAME)
        print(MISSION_QUESTION)
        print("=" * 72)
        print(f"Secuencia planificada: h0_real -> h0_real + {config.step_cm} cm -> h0_real")
        print("Conectando con el dron...")

        drone.connect()
        battery = safe_get_battery(drone)
        metadata["bateria_inicial"] = battery
        print(f"Batería inicial: {battery:.0f} %")

        if not mock and battery < config.min_battery_percent:
            raise RuntimeError(f"Batería insuficiente. Se recomienda al menos {config.min_battery_percent} %.")

        input("\nVerifica zona despejada y autorización del profesor. Presiona ENTER para despegar...")

        print("Despegando...")
        drone.takeoff()
        airborne = True
        time.sleep(config.takeoff_settle_s)

        try:
            drone.set_speed(config.command_speed_cm_s)
            print(f"Velocidad de comando configurada: {config.command_speed_cm_s} cm/s")
        except Exception as exc:  # noqa: BLE001
            print(f"[ADVERTENCIA] No se pudo configurar velocidad: {exc}")

        h0_cm = median_height_cm(drone, n=9, sample_period_s=0.08)
        if math.isnan(h0_cm):
            raise RuntimeError("No se pudo medir la altura inicial estable.")

        h0_cm = float(round(h0_cm))
        h_high_cm = h0_cm + config.step_cm

        print("\nCondición inicial aceptada sin ajuste automático de altura")
        print(f"Altura inicial real medida: {h0_cm:.0f} cm")
        print(f"Ascenso: +{config.step_cm} cm -> referencia alta {h_high_cm:.0f} cm")
        print(f"Descenso: -{config.step_cm} cm -> referencia inicial {h0_cm:.0f} cm")
        print(f"Muestreo objetivo: {1/config.sample_period_s:.1f} Hz")

        if h0_cm < config.min_allowed_initial_height_cm or h0_cm > config.max_allowed_initial_height_cm:
            raise RuntimeError(
                f"Altura inicial fuera de rango seguro: {h0_cm:.0f} cm. "
                f"Rango recomendado: {config.min_allowed_initial_height_cm}–{config.max_allowed_initial_height_cm} cm."
            )

        if h_high_cm > config.max_allowed_final_height_cm:
            raise RuntimeError(
                f"La altura alta estimada sería {h_high_cm:.0f} cm, mayor que el límite de clase "
                f"({config.max_allowed_final_height_cm} cm). Reduce step_cm."
            )

        metadata["altura_inicial_real_cm"] = h0_cm
        metadata["altura_alta_referencia_cm"] = h_high_cm
        metadata["altura_final_referencia_cm"] = h0_cm

        recorder = TelemetryRecorder(drone=drone, config=config)
        recorder.set_state(phase="antes_ascenso", reference_cm=h0_cm)
        recorder.start()

        time.sleep(config.initial_hold_s)

        print(f"\nAplicando ascenso: move_up({config.step_cm} cm)...")
        metadata["tiempo_aplicacion_ascenso_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_up", reference_cm=h_high_cm)
        drone.move_up(config.step_cm)
        metadata["tiempo_fin_ascenso_s"] = recorder.elapsed()
        metadata["duracion_comando_ascenso_s"] = metadata["tiempo_fin_ascenso_s"] - metadata["tiempo_aplicacion_ascenso_s"]

        print(f"Manteniendo referencia alta durante {hold_high_s:.1f} s...")
        recorder.set_state(phase="arriba_estable", reference_cm=h_high_cm)
        time.sleep(hold_high_s)

        print(f"\nAplicando descenso: move_down({config.step_cm} cm)...")
        metadata["tiempo_aplicacion_descenso_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_down", reference_cm=h0_cm)
        move_down_compatible(drone, config.step_cm)
        metadata["tiempo_fin_descenso_s"] = recorder.elapsed()
        metadata["duracion_comando_descenso_s"] = metadata["tiempo_fin_descenso_s"] - metadata["tiempo_aplicacion_descenso_s"]

        recorder.set_state(phase="despues_descenso", reference_cm=h0_cm)
        time.sleep(config.after_step_hold_s)
        recorder.stop()

        print("\nAterrizando...")
        aterrizo_ok = safe_land(drone)
        airborne = False
        if not aterrizo_ok:
            raise RuntimeError("El aterrizaje automático falló. Revisar dron antes de repetir la práctica.")

        metadata["timestamp_fin"] = time.strftime("%Y-%m-%d %H:%M:%S")
        metadata["bateria_final"] = safe_get_battery(drone)

        df = save_results(recorder.samples, config, metadata)
        plot_results(df, config)
        print_quality_check(df)

        metrics_df = estimate_ascent_descent_metrics(df, config.step_cm)
        summary_path = Path("datos") / f"{prefix}_resumen.csv"
        summary_path.parent.mkdir(parents=True, exist_ok=True)
        metrics_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
        print(f"Resumen por tramos guardado en: {summary_path}")

        metadata["metricas_preliminares_por_tramo"] = metrics_df.to_dict(orient="records")
        with open(config.output_metadata, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=4, ensure_ascii=False)

        plot_ascent_descent_segments(df, metadata, prefix)
        plot_deviation_comparison(df, metadata, prefix)

        print("\nExperimento ascenso-descenso completado correctamente.")
        print("Archivos clave:")
        print(f"  - {config.output_csv}")
        print(f"  - {config.output_metadata}")
        print(f"  - {summary_path}")
        print(f"  - {config.output_plot}")
        print(f"  - salidas/{prefix}_tramos.png")
        print(f"  - salidas/{prefix}_desviacion.png")

    except KeyboardInterrupt:
        print("\nInterrupción manual detectada.")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando aterrizar por seguridad...")
            safe_land(drone)
        raise

    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR] Ascenso-descenso: {exc}")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando estabilizar y aterrizar por seguridad...")
            safe_land(drone)
        raise

    finally:
        try:
            if hasattr(drone, "is_flying") and not getattr(drone, "is_flying"):
                drone.end()
            elif not airborne:
                drone.end()
        except Exception:
            pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Equipo 6 — Ascenso-descenso con Tello.")
    parser.add_argument("--mock", action="store_true", help="Ejecuta simulación sin dron real.")
    parser.add_argument("--step-cm", type=int, default=30, help="Magnitud del ascenso y descenso en cm. Recomendado: 30.")
    parser.add_argument("--sample-period", type=float, default=0.10, help="Periodo de muestreo en segundos. Recomendado: 0.10.")
    parser.add_argument("--initial-hold", type=float, default=3.0, help="Tiempo antes del ascenso, en segundos.")
    parser.add_argument("--hold-high", type=float, default=5.0, help="Tiempo en referencia alta antes del descenso, en segundos.")
    parser.add_argument("--after-hold", type=float, default=6.0, help="Tiempo después del descenso, en segundos.")
    parser.add_argument("--prefix", default="equipo06_ascenso_descenso", help="Prefijo de archivos de salida.")
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    if args.step_cm < 20:
        raise ValueError("El SDK del Tello requiere movimientos de al menos 20 cm.")
    if args.step_cm > 40:
        raise ValueError("Para clase se recomienda step-cm <= 40 en la misión ascenso-descenso.")
    if args.hold_high < 3:
        raise ValueError("Se recomienda hold-high >= 3 s para observar la transición antes de descender.")


if __name__ == "__main__":
    args = parse_args()
    try:
        validate_args(args)
        cfg = ExperimentConfig(
            step_cm=args.step_cm,
            sample_period_s=args.sample_period,
            initial_hold_s=args.initial_hold,
            after_step_hold_s=args.after_hold,
        )
        cfg = build_ascent_descent_config(cfg, args.step_cm, args.prefix)

        run_ascent_descent_experiment(
            mock=args.mock,
            config=cfg,
            hold_high_s=args.hold_high,
            prefix=args.prefix,
        )
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR GENERAL] {exc}")
        sys.exit(1)
