"""
Sesión 6 — Bloque 5: Equipo 5, Punto de operación
MR2023 Modelación para Automatización

Extensión mínima de experimento_patron_tello_v3.py.

Objetivo didáctico:
    Comparar dos escalones ascendentes de igual magnitud, pero aplicados desde
    diferentes zonas de operación:

        Prueba baja: h0_bajo_real -> h0_bajo_real + 30 cm
        Prueba alta: h0_alto_real -> h0_alto_real + 30 cm

    y generar evidencia para responder:

        ¿El mismo cambio de altura se comporta igual en diferentes zonas?

Decisión de seguridad y didáctica:
    No se fuerzan alturas absolutas 0.40 m -> 0.70 m y 0.80 m -> 1.10 m.
    La prueba baja usa la altura estable natural después del despegue.
    La prueba alta realiza una subida previa controlada y luego aplica el mismo
    escalón de identificación. Esto reduce fricción técnica y mantiene el foco
    en modelación y validez local.

Uso recomendado con dron real:
    python src/experimento_punto_operacion_equipo05.py

Uso sin dron para prueba del flujo:
    python src/experimento_punto_operacion_equipo05.py --mock

Salidas principales:
    datos/equipo05_punto_operacion_bajo_030cm.csv
    datos/equipo05_punto_operacion_alto_030cm.csv
    datos/equipo05_punto_operacion_resumen.csv
    salidas/equipo05_punto_operacion_comparacion_altura.png
    salidas/equipo05_punto_operacion_comparacion_desviacion.png
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from experimento_patron_tello_v3 import (
    ExperimentConfig,
    TelemetryRecorder,
    create_drone,
    ensure_output_dirs,
    median_height_cm,
    plot_results,
    print_quality_check,
    safe_get_battery,
    safe_land,
    save_results,
    validate_config_for_real_drone,
)


MISSION_NAME = "Equipo 5 — Punto de operación"
MISSION_QUESTION = "¿El mismo cambio de altura se comporta igual en diferentes zonas?"


def build_point_config(base: ExperimentConfig, zone: str, step_cm: int, prefix: str) -> ExperimentConfig:
    """Crea nombres de salida para cada zona sin cambiar la lógica base de v3."""
    stem = f"{prefix}_{zone}_{step_cm:03d}cm"
    return ExperimentConfig(
        step_cm=step_cm,
        initial_hold_s=base.initial_hold_s,
        after_step_hold_s=base.after_step_hold_s,
        sample_period_s=base.sample_period_s,
        min_battery_percent=base.min_battery_percent,
        max_allowed_final_height_cm=base.max_allowed_final_height_cm,
        min_allowed_initial_height_cm=base.min_allowed_initial_height_cm,
        max_allowed_initial_height_cm=base.max_allowed_initial_height_cm,
        takeoff_settle_s=base.takeoff_settle_s,
        command_speed_cm_s=base.command_speed_cm_s,
        output_csv=f"datos/{stem}.csv",
        output_plot=f"salidas/{stem}.png",
        output_metadata=f"datos/{stem}_metadata.json",
    )


def estimate_basic_metrics(df: pd.DataFrame, step_cm: int) -> dict[str, float]:
    """Calcula métricas preliminares para cada punto de operación.

    No sustituye el análisis formal posterior. Solo permite validar rápidamente
    si los datos son útiles para comparar K, tau, sobreimpulso y error.
    """
    if df.empty:
        return {}

    before = df[df["fase"] == "antes_del_escalon"] if "fase" in df.columns else pd.DataFrame()
    after = df[df["fase"] == "despues_del_escalon"] if "fase" in df.columns else pd.DataFrame()
    during = df[df["fase"] == "durante_comando_up"] if "fase" in df.columns else pd.DataFrame()

    h0 = float(before["altura"].median()) if not before.empty else float(df["altura"].iloc[:10].mean())
    hf = float(after["altura"].tail(10).mean()) if not after.empty else float(df["altura"].iloc[-10:].mean())
    delta_h = hf - h0
    delta_r = step_cm / 100.0
    k_est = delta_h / delta_r if delta_r != 0 else float("nan")

    t_start = float(during["tiempo"].min()) if not during.empty else float(df["tiempo"].iloc[0])
    h63 = h0 + 0.632 * delta_h
    post = df[df["tiempo"] >= t_start].copy()

    tau = float("nan")
    t63 = float("nan")
    if not post.empty and delta_h > 0:
        reached = post[post["altura"] >= h63]
        if not reached.empty:
            t63 = float(reached["tiempo"].iloc[0])
            tau = t63 - t_start

    overshoot_m = float(df["altura"].max() - hf)
    overshoot_pct = float((overshoot_m / delta_h) * 100.0) if delta_h > 1e-9 else float("nan")
    rms_to_reference = float(math.sqrt(((df["altura"] - df["referencia"]) ** 2).mean()))

    return {
        "step_cm": float(step_cm),
        "h0_m": h0,
        "hf_m": hf,
        "delta_h_m": delta_h,
        "delta_r_m": delta_r,
        "K_preliminar": k_est,
        "h63_m": h63,
        "t_inicio_escalon_s": t_start,
        "t63_s": t63,
        "tau_preliminar_s": tau,
        "sobreimpulso_aprox_m": overshoot_m,
        "sobreimpulso_aprox_pct": overshoot_pct,
        "rms_altura_vs_referencia_m": rms_to_reference,
        "muestras": float(len(df)),
        "duracion_s": float(df["tiempo"].max() - df["tiempo"].min()),
    }


def run_single_operating_point(
    zone_label: str,
    test_index: int,
    total_tests: int,
    pre_up_cm: int,
    mock: bool,
    config: ExperimentConfig,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Ejecuta una prueba completa para una zona de operación."""
    validate_config_for_real_drone(config, mock)
    ensure_output_dirs(config)

    drone = create_drone(mock)
    metadata: dict[str, Any] = {
        "curso": "MR2023 Modelación para Automatización",
        "sesion": "Sesión 6",
        "bloque": "Bloque 5 — Campaña experimental por equipos",
        "equipo": 5,
        "mision": MISSION_NAME,
        "pregunta_investigacion": MISSION_QUESTION,
        "zona_operacion": zone_label,
        "prueba": test_index,
        "total_pruebas": total_tests,
        "step_cm": config.step_cm,
        "pre_up_cm": pre_up_cm,
        "experimento": "Mismo escalón relativo aplicado desde una zona de operación específica",
        "configuracion": asdict(config),
        "modo_mock": mock,
        "timestamp_inicio": time.strftime("%Y-%m-%d %H:%M:%S"),
        "nota": (
            "Extensión mínima de v3. Se compara el mismo escalón relativo desde dos zonas de operación. "
            "La zona baja usa hover estable natural; la zona alta usa una subida previa controlada."
        ),
    }

    airborne = False
    recorder: TelemetryRecorder | None = None

    try:
        print("\n" + "=" * 72)
        print(f"{MISSION_NAME} | Prueba {test_index}/{total_tests} | Zona {zone_label.upper()}")
        print("=" * 72)
        print("Conectando con el dron...")
        drone.connect()
        battery = safe_get_battery(drone)
        metadata["bateria_inicial"] = battery
        print(f"Batería inicial: {battery:.0f} %")

        if not mock and battery < config.min_battery_percent:
            raise RuntimeError(f"Batería insuficiente. Se recomienda al menos {config.min_battery_percent} %.")

        input("\nVerifica zona despejada y autorización del profesor. Presiona ENTER para despegar...")

        print("Despegando...")
        drone.takeoff()
        airborne = True
        time.sleep(config.takeoff_settle_s)

        try:
            drone.set_speed(config.command_speed_cm_s)
            print(f"Velocidad de comando configurada: {config.command_speed_cm_s} cm/s")
        except Exception as exc:  # noqa: BLE001
            print(f"[ADVERTENCIA] No se pudo configurar velocidad: {exc}")

        if pre_up_cm > 0:
            h_pre_cm = median_height_cm(drone, n=7, sample_period_s=0.08)
            if math.isnan(h_pre_cm):
                raise RuntimeError("No se pudo medir altura antes del preposicionamiento.")
            h_pre_cm = float(round(h_pre_cm))
            altura_estimada_final_cm = h_pre_cm + pre_up_cm + config.step_cm
            if altura_estimada_final_cm > config.max_allowed_final_height_cm:
                raise RuntimeError(
                    f"La zona alta estimada terminaría en {altura_estimada_final_cm:.0f} cm, "
                    f"mayor que el límite de clase ({config.max_allowed_final_height_cm} cm). "
                    "Reduce --high-pre-up-cm o --step-cm."
                )
            print(f"\nPreposicionamiento para zona alta: move_up({pre_up_cm} cm)...")
            metadata["altura_antes_preposicion_cm"] = h_pre_cm
            metadata["altura_final_estimada_zona_alta_cm"] = altura_estimada_final_cm
            metadata["tiempo_inicio_preposicionamiento_s"] = 0.0
            drone.move_up(pre_up_cm)
            print("Estabilizando en zona alta antes del escalón de identificación...")
            time.sleep(config.takeoff_settle_s)

        h0_cm = median_height_cm(drone, n=9, sample_period_s=0.08)
        if math.isnan(h0_cm):
            raise RuntimeError("No se pudo medir la altura inicial estable del punto de operación.")

        h0_cm = float(round(h0_cm))
        hf_cm = h0_cm + config.step_cm

        print("\nPunto de operación aceptado sin ajuste automático fino")
        print(f"Zona: {zone_label}")
        print(f"Altura inicial real medida: {h0_cm:.0f} cm")
        print(f"Escalón relativo aplicado: +{config.step_cm} cm")
        print(f"Referencia experimental: {h0_cm:.0f} cm -> {hf_cm:.0f} cm")
        print(f"Muestreo objetivo: {1/config.sample_period_s:.1f} Hz")

        if h0_cm < config.min_allowed_initial_height_cm or h0_cm > config.max_allowed_initial_height_cm:
            raise RuntimeError(
                f"Altura inicial fuera de rango seguro: {h0_cm:.0f} cm. "
                f"Rango recomendado: {config.min_allowed_initial_height_cm}–{config.max_allowed_initial_height_cm} cm."
            )

        if hf_cm > config.max_allowed_final_height_cm:
            raise RuntimeError(
                f"La altura final estimada sería {hf_cm:.0f} cm, mayor que el límite de clase "
                f"({config.max_allowed_final_height_cm} cm). Reduce pre_up_cm o step_cm."
            )

        metadata["altura_inicial_real_cm"] = h0_cm
        metadata["altura_final_referencia_cm"] = hf_cm

        recorder = TelemetryRecorder(drone=drone, config=config)
        recorder.set_state(phase="antes_del_escalon", reference_cm=h0_cm)
        recorder.start()

        time.sleep(config.initial_hold_s)

        print(f"\nAplicando escalón de identificación: move_up({config.step_cm} cm)...")
        metadata["tiempo_aplicacion_escalon_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_up", reference_cm=hf_cm)

        drone.move_up(config.step_cm)

        metadata["tiempo_fin_comando_s"] = recorder.elapsed()
        metadata["duracion_comando_s"] = metadata["tiempo_fin_comando_s"] - metadata["tiempo_aplicacion_escalon_s"]
        recorder.set_state(phase="despues_del_escalon", reference_cm=hf_cm)

        time.sleep(config.after_step_hold_s)
        recorder.stop()

        print("\nAterrizando...")
        aterrizo_ok = safe_land(drone)
        airborne = False
        if not aterrizo_ok:
            raise RuntimeError("El aterrizaje automático falló. Revisar dron antes de repetir la práctica.")

        metadata["timestamp_fin"] = time.strftime("%Y-%m-%d %H:%M:%S")
        metadata["bateria_final"] = safe_get_battery(drone)

        df = save_results(recorder.samples, config, metadata)
        plot_results(df, config)
        print_quality_check(df)

        metrics = estimate_basic_metrics(df, config.step_cm)
        metadata["metricas_preliminares"] = metrics

        with open(config.output_metadata, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=4, ensure_ascii=False)

        print("\nPrueba de punto de operación completada correctamente.")
        return df, metadata

    except KeyboardInterrupt:
        print("\nInterrupción manual detectada.")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando aterrizar por seguridad...")
            safe_land(drone)
        raise

    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR] Zona {zone_label}: {exc}")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando estabilizar y aterrizar por seguridad...")
            safe_land(drone)
        raise

    finally:
        try:
            if hasattr(drone, "is_flying") and not getattr(drone, "is_flying"):
                drone.end()
            elif not airborne:
                drone.end()
        except Exception:
            pass


def save_summary(metadatas: list[dict[str, Any]], prefix: str) -> pd.DataFrame:
    """Guarda un resumen comparativo bajo vs alto."""
    rows: list[dict[str, Any]] = []
    for meta in metadatas:
        row: dict[str, Any] = {
            "zona_operacion": meta.get("zona_operacion"),
            "archivo_csv": meta.get("configuracion", {}).get("output_csv"),
            "bateria_inicial": meta.get("bateria_inicial"),
            "bateria_final": meta.get("bateria_final"),
            "pre_up_cm": meta.get("pre_up_cm"),
            "step_cm": meta.get("step_cm"),
            "altura_inicial_real_cm": meta.get("altura_inicial_real_cm"),
            "altura_final_referencia_cm": meta.get("altura_final_referencia_cm"),
        }
        row.update(meta.get("metricas_preliminares", {}))
        rows.append(row)

    summary = pd.DataFrame(rows)
    output = Path("datos") / f"{prefix}_resumen.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output, index=False, encoding="utf-8-sig")
    print(f"\nResumen comparativo guardado en: {output}")
    return summary


def plot_operating_point_comparison(dfs: list[pd.DataFrame], labels: list[str], prefix: str) -> None:
    """Genera dos gráficas: altura absoluta y desviación respecto a h0."""
    if not dfs:
        return

    # Comparación en altura absoluta.
    plt.figure(figsize=(9, 5))
    for df, label in zip(dfs, labels, strict=False):
        if df.empty:
            continue
        t0 = float(df["tiempo"].iloc[0])
        plt.plot(df["tiempo"] - t0, df["altura"], linewidth=1.6, label=f"{label} — altura")
        plt.plot(df["tiempo"] - t0, df["referencia"], "--", linewidth=1.0, label=f"{label} — referencia")
    plt.grid(True)
    plt.xlabel("Tiempo relativo [s]")
    plt.ylabel("Altura [m]")
    plt.title("Equipo 5 — Punto de operación: comparación en altura absoluta")
    plt.legend(loc="best")
    plt.tight_layout()
    output_abs = Path("salidas") / f"{prefix}_comparacion_altura.png"
    output_abs.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_abs, dpi=200)
    plt.close()
    print(f"Gráfica de altura absoluta guardada en: {output_abs}")

    # Comparación en variable de desviación: h - h0.
    plt.figure(figsize=(9, 5))
    for df, label in zip(dfs, labels, strict=False):
        if df.empty:
            continue
        t0 = float(df["tiempo"].iloc[0])
        before = df[df["fase"] == "antes_del_escalon"] if "fase" in df.columns else pd.DataFrame()
        h0 = float(before["altura"].median()) if not before.empty else float(df["altura"].iloc[:10].mean())
        r0 = float(before["referencia"].median()) if not before.empty else float(df["referencia"].iloc[:10].mean())
        plt.plot(df["tiempo"] - t0, df["altura"] - h0, linewidth=1.8, label=f"{label} — Δh")
        plt.plot(df["tiempo"] - t0, df["referencia"] - r0, "--", linewidth=1.0, label=f"{label} — Δr")
    plt.grid(True)
    plt.xlabel("Tiempo relativo [s]")
    plt.ylabel("Variable de desviación [m]")
    plt.title("Equipo 5 — Comparación en variables de desviación")
    plt.legend(loc="best")
    plt.tight_layout()
    output_dev = Path("salidas") / f"{prefix}_comparacion_desviacion.png"
    plt.savefig(output_dev, dpi=200)
    plt.close()
    print(f"Gráfica de variable de desviación guardada en: {output_dev}")


def run_operating_point_experiment(
    mock: bool,
    step_cm: int,
    high_pre_up_cm: int,
    base_config: ExperimentConfig,
    prefix: str,
) -> None:
    """Ejecuta las dos pruebas: zona baja y zona alta."""
    test_plan = [
        ("bajo", 0),
        ("alto", high_pre_up_cm),
    ]

    dfs: list[pd.DataFrame] = []
    metadatas: list[dict[str, Any]] = []
    labels: list[str] = []

    for idx, (zone, pre_up_cm) in enumerate(test_plan, start=1):
        cfg = build_point_config(base_config, zone=zone, step_cm=step_cm, prefix=prefix)
        df, meta = run_single_operating_point(
            zone_label=zone,
            test_index=idx,
            total_tests=len(test_plan),
            pre_up_cm=pre_up_cm,
            mock=mock,
            config=cfg,
        )
        dfs.append(df)
        metadatas.append(meta)
        labels.append(f"Zona {zone}")

        if idx < len(test_plan):
            print("\n" + "-" * 72)
            print("Prueba baja terminada. La siguiente prueba será en zona alta.")
            input("Revisa batería/zona de vuelo. Presiona ENTER para continuar...")

    save_summary(metadatas, prefix)
    plot_operating_point_comparison(dfs, labels, prefix)

    print("\nExperimento de punto de operación completado.")
    print("Archivos clave:")
    print(f"  - datos/{prefix}_bajo_{step_cm:03d}cm.csv")
    print(f"  - datos/{prefix}_alto_{step_cm:03d}cm.csv")
    print(f"  - datos/{prefix}_resumen.csv")
    print(f"  - salidas/{prefix}_comparacion_altura.png")
    print(f"  - salidas/{prefix}_comparacion_desviacion.png")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Equipo 5 — Punto de operación con Tello.")
    parser.add_argument("--mock", action="store_true", help="Ejecuta simulación sin dron real.")
    parser.add_argument("--step-cm", type=int, default=30, help="Escalón de identificación en cm. Recomendado: 30.")
    parser.add_argument("--high-pre-up-cm", type=int, default=30, help="Subida previa para zona alta en cm. Recomendado: 30.")
    parser.add_argument("--sample-period", type=float, default=0.10, help="Periodo de muestreo en segundos. Recomendado: 0.10.")
    parser.add_argument("--initial-hold", type=float, default=3.0, help="Tiempo antes del escalón de identificación, en segundos.")
    parser.add_argument("--after-hold", type=float, default=8.0, help="Tiempo después del escalón de identificación, en segundos.")
    parser.add_argument("--prefix", default="equipo05_punto_operacion", help="Prefijo de archivos de salida.")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if args.step_cm < 20:
        print("[ERROR] El SDK del Tello requiere movimientos de al menos 20 cm.")
        sys.exit(1)
    if args.high_pre_up_cm != 0 and args.high_pre_up_cm < 20:
        print("[ERROR] Si se usa preposicionamiento, debe ser 0 o al menos 20 cm.")
        sys.exit(1)
    if args.step_cm > 40:
        print("[ERROR] Para clase se recomienda step_cm <= 40. Usa 30 cm como valor base.")
        sys.exit(1)
    if args.high_pre_up_cm > 40:
        print("[ERROR] Para clase se recomienda high_pre_up_cm <= 40.")
        sys.exit(1)

    cfg = ExperimentConfig(
        step_cm=args.step_cm,
        sample_period_s=args.sample_period,
        initial_hold_s=args.initial_hold,
        after_step_hold_s=args.after_hold,
    )

    try:
        run_operating_point_experiment(
            mock=args.mock,
            step_cm=args.step_cm,
            high_pre_up_cm=args.high_pre_up_cm,
            base_config=cfg,
            prefix=args.prefix,
        )
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR GENERAL] {exc}")
        sys.exit(1)
