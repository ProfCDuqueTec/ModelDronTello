@echo off
python src/experimento_punto_operacion_equipo05.py --mock
pause
