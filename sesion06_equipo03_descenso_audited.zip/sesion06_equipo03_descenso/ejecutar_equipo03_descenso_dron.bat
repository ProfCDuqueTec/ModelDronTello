@echo off
python src/experimento_descenso_equipo03.py
pause
