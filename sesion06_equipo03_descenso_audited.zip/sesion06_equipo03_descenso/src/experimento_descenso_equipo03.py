"""
Sesión 6 — Bloque 5: Equipo 3, Escalón descendente
MR2023 Modelación para Automatización

Extensión mínima de experimento_patron_tello_v3.py.

Objetivo didáctico:
    Ejecutar un escalón vertical relativo descendente:

        h0_alto_real -> h0_alto_real - 30 cm

    y generar evidencia para responder:

        ¿Bajar es dinámicamente equivalente a subir?

Decisión experimental:
    No se fuerza una altura absoluta exacta. El dron despega, sube primero a una
    zona segura de análisis, se estabiliza, registra el tramo inicial y después
    ejecuta move_down(step_cm). El CSV contiene solo el tramo útil del descenso.

Uso con dron real:
    python src/experimento_descenso_equipo03.py

Uso sin dron:
    python src/experimento_descenso_equipo03.py --mock

Salidas principales:
    datos/equipo03_descenso_030cm.csv
    datos/equipo03_descenso_resumen.csv
    salidas/equipo03_descenso_030cm.png
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from experimento_patron_tello_v3 import (
    ExperimentConfig,
    TelemetryRecorder,
    create_drone,
    ensure_output_dirs,
    median_height_cm,
    plot_results,
    print_quality_check,
    safe_get_battery,
    safe_land,
    save_results,
    validate_config_for_real_drone,
)


MISSION_NAME = "Equipo 3 — Escalón descendente"
MISSION_QUESTION = "¿Bajar es dinámicamente equivalente a subir?"


def build_descent_config(base: ExperimentConfig, step_cm: int, prefix: str) -> ExperimentConfig:
    """Crea nombres de salida específicos del descenso sin modificar la lógica v3."""
    stem = f"{prefix}_{step_cm:03d}cm"
    return ExperimentConfig(
        step_cm=step_cm,
        initial_hold_s=base.initial_hold_s,
        after_step_hold_s=base.after_step_hold_s,
        sample_period_s=base.sample_period_s,
        min_battery_percent=base.min_battery_percent,
        max_allowed_final_height_cm=base.max_allowed_final_height_cm,
        min_allowed_initial_height_cm=base.min_allowed_initial_height_cm,
        max_allowed_initial_height_cm=base.max_allowed_initial_height_cm,
        takeoff_settle_s=base.takeoff_settle_s,
        command_speed_cm_s=base.command_speed_cm_s,
        output_csv=f"datos/{stem}.csv",
        output_plot=f"salidas/{stem}.png",
        output_metadata=f"datos/{stem}_metadata.json",
    )


def move_down_compatible(drone: Any, cm: int) -> None:
    """Ejecuta descenso real; en mock simula el comando porque la v3 solo trae move_up."""
    if hasattr(drone, "move_down"):
        drone.move_down(cm)
        return

    # Compatibilidad con MockTello de la v3.
    print(f"[MOCK] Comando down {cm} cm.")
    if hasattr(drone, "get_height"):
        current = float(drone.get_height())
    else:
        current = 100.0

    # El mock de v3 usa estos atributos internos para simular una respuesta de 1er orden.
    if hasattr(drone, "_step_start_height"):
        drone._step_start_height = current  # noqa: SLF001
    if hasattr(drone, "_step_target_height"):
        drone._step_target_height = current - cm  # noqa: SLF001
    if hasattr(drone, "_step_start_time"):
        drone._step_start_time = time.monotonic()  # noqa: SLF001
    time.sleep(2.8)


def estimate_descent_metrics(df: pd.DataFrame, step_cm: int) -> dict[str, float]:
    """Calcula métricas preliminares del escalón descendente.

    El análisis formal sigue quedando para la tarea posterior. Aquí solo se valida
    si el CSV tiene una dinámica descendente útil para modelación.
    """
    if df.empty:
        return {}

    before = df[df["fase"] == "antes_del_escalon"] if "fase" in df.columns else pd.DataFrame()
    after = df[df["fase"] == "despues_del_escalon"] if "fase" in df.columns else pd.DataFrame()
    during = df[df["fase"] == "durante_comando_down"] if "fase" in df.columns else pd.DataFrame()

    h0 = float(before["altura"].median()) if not before.empty else float(df["altura"].iloc[:10].mean())
    hf = float(after["altura"].tail(10).mean()) if not after.empty else float(df["altura"].iloc[-10:].mean())

    delta_h = hf - h0
    delta_r = -step_cm / 100.0
    k_est = delta_h / delta_r if delta_r != 0 else float("nan")

    t_start = float(during["tiempo"].min()) if not during.empty else float(df["tiempo"].iloc[0])
    h63 = h0 + 0.632 * delta_h
    post = df[df["tiempo"] >= t_start].copy()

    tau = float("nan")
    t63 = float("nan")
    if not post.empty and delta_h < 0:
        reached = post[post["altura"] <= h63]
        if not reached.empty:
            t63 = float(reached["tiempo"].iloc[0])
            tau = t63 - t_start

    # Para descenso, el sobreimpulso relevante es ir por debajo del valor final.
    undershoot_m = float(hf - df["altura"].min())
    undershoot_pct = float((undershoot_m / abs(delta_h)) * 100.0) if abs(delta_h) > 1e-9 else float("nan")
    rms_to_reference = float(math.sqrt(((df["altura"] - df["referencia"]) ** 2).mean()))

    return {
        "step_cm": float(step_cm),
        "h0_alto_m": h0,
        "hf_m": hf,
        "delta_h_m": delta_h,
        "delta_r_m": delta_r,
        "K_preliminar": k_est,
        "h63_m": h63,
        "t_inicio_escalon_s": t_start,
        "t63_s": t63,
        "tau_preliminar_s": tau,
        "sobreimpulso_hacia_abajo_aprox_m": undershoot_m,
        "sobreimpulso_hacia_abajo_aprox_pct": undershoot_pct,
        "rms_altura_vs_referencia_m": rms_to_reference,
        "muestras": float(len(df)),
        "duracion_s": float(df["tiempo"].max() - df["tiempo"].min()),
    }


def save_descent_summary(metadata: dict[str, Any], prefix: str) -> pd.DataFrame:
    row: dict[str, Any] = {
        "archivo_csv": metadata.get("configuracion", {}).get("output_csv"),
        "bateria_inicial": metadata.get("bateria_inicial"),
        "bateria_final": metadata.get("bateria_final"),
        "altura_preposicion_cm": metadata.get("altura_preposicion_cm"),
        "altura_inicial_descenso_cm": metadata.get("altura_inicial_descenso_cm"),
        "altura_final_referencia_cm": metadata.get("altura_final_referencia_cm"),
        "step_cm": metadata.get("step_cm"),
        "pre_up_cm": metadata.get("pre_up_cm"),
    }
    row.update(metadata.get("metricas_preliminares", {}))
    summary = pd.DataFrame([row])
    output = Path("datos") / f"{prefix}_resumen.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output, index=False, encoding="utf-8-sig")
    print(f"Resumen del descenso guardado en: {output}")
    return summary


def plot_descent_focus(df: pd.DataFrame, prefix: str) -> None:
    """Genera una gráfica adicional enfocada en altura y referencia del descenso."""
    if df.empty:
        return
    t0 = float(df["tiempo"].iloc[0])
    plt.figure(figsize=(9, 5))
    plt.plot(df["tiempo"] - t0, df["referencia"], "--", linewidth=1.2, label="Referencia")
    plt.plot(df["tiempo"] - t0, df["altura"], linewidth=1.8, label="Altura medida")
    plt.grid(True)
    plt.xlabel("Tiempo relativo [s]")
    plt.ylabel("Altura [m]")
    plt.title("Equipo 3 — Escalón descendente")
    plt.legend(loc="best")
    plt.tight_layout()

    output = Path("salidas") / f"{prefix}_comparacion.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=200)
    plt.close()
    print(f"Gráfica comparativa del descenso guardada en: {output}")


def run_descent_experiment(mock: bool, config: ExperimentConfig, pre_up_cm: int, prefix: str) -> None:
    validate_config_for_real_drone(config, mock)
    ensure_output_dirs(config)

    drone = create_drone(mock)
    metadata: dict[str, Any] = {
        "curso": "MR2023 Modelación para Automatización",
        "sesion": "Sesión 6",
        "bloque": "Bloque 5 — Campaña experimental por equipos",
        "equipo": 3,
        "mision": MISSION_NAME,
        "pregunta_investigacion": MISSION_QUESTION,
        "experimento": "Escalón relativo descendente desde una altura inicial segura",
        "step_cm": config.step_cm,
        "pre_up_cm": pre_up_cm,
        "configuracion": asdict(config),
        "modo_mock": mock,
        "timestamp_inicio": time.strftime("%Y-%m-%d %H:%M:%S"),
        "nota": (
            "Extensión mínima de v3. Primero se sube el dron a una zona segura de análisis, "
            "se estabiliza y después se registra un escalón descendente relativo."
        ),
    }

    airborne = False
    recorder: TelemetryRecorder | None = None

    try:
        print("\n" + "#" * 72)
        print(MISSION_NAME)
        print(MISSION_QUESTION)
        print("#" * 72)
        print(f"Secuencia: despegue -> subir {pre_up_cm} cm -> estabilizar -> bajar {config.step_cm} cm")

        print("\nConectando con el dron...")
        drone.connect()
        battery = safe_get_battery(drone)
        metadata["bateria_inicial"] = battery
        print(f"Batería inicial: {battery:.0f} %")

        if not mock and battery < config.min_battery_percent:
            raise RuntimeError(f"Batería insuficiente. Se recomienda al menos {config.min_battery_percent} %.")

        input("\nVerifica zona despejada y autorización del profesor. Presiona ENTER para despegar...")

        print("Despegando...")
        drone.takeoff()
        airborne = True
        time.sleep(config.takeoff_settle_s)

        try:
            drone.set_speed(config.command_speed_cm_s)
            print(f"Velocidad de comando configurada: {config.command_speed_cm_s} cm/s")
        except Exception as exc:  # noqa: BLE001
            print(f"[ADVERTENCIA] No se pudo configurar velocidad: {exc}")

        h_takeoff_cm = median_height_cm(drone, n=9, sample_period_s=0.08)
        if math.isnan(h_takeoff_cm):
            raise RuntimeError("No se pudo medir la altura posterior al despegue.")
        h_takeoff_cm = float(round(h_takeoff_cm))
        metadata["altura_post_despegue_cm"] = h_takeoff_cm

        print(f"\nAltura después del despegue: {h_takeoff_cm:.0f} cm")
        print(f"Preposicionamiento: move_up({pre_up_cm} cm) para iniciar el descenso desde zona segura...")
        if h_takeoff_cm + pre_up_cm > config.max_allowed_final_height_cm:
            raise RuntimeError(
                f"El preposicionamiento estimado llegaría a {h_takeoff_cm + pre_up_cm:.0f} cm, "
                f"mayor que el límite de clase ({config.max_allowed_final_height_cm} cm)."
            )
        drone.move_up(pre_up_cm)
        time.sleep(2.0)

        h0_cm = median_height_cm(drone, n=9, sample_period_s=0.08)
        if math.isnan(h0_cm):
            raise RuntimeError("No se pudo medir la altura inicial del descenso.")
        h0_cm = float(round(h0_cm))
        hf_cm = h0_cm - config.step_cm

        print("\nCondición inicial del descenso aceptada")
        print(f"Altura inicial de descenso medida: {h0_cm:.0f} cm")
        print(f"Escalón relativo aplicado: -{config.step_cm} cm")
        print(f"Referencia experimental: {h0_cm:.0f} cm -> {hf_cm:.0f} cm")
        print(f"Muestreo objetivo: {1/config.sample_period_s:.1f} Hz")

        if h0_cm < config.min_allowed_initial_height_cm or h0_cm > config.max_allowed_final_height_cm:
            raise RuntimeError(
                f"Altura inicial de descenso fuera de rango seguro: {h0_cm:.0f} cm. "
                f"Rango recomendado: {config.min_allowed_initial_height_cm}–{config.max_allowed_final_height_cm} cm."
            )
        if hf_cm < config.min_allowed_initial_height_cm:
            raise RuntimeError(
                f"La altura final estimada sería {hf_cm:.0f} cm, menor que el límite seguro "
                f"({config.min_allowed_initial_height_cm} cm). Reduce step_cm o aumenta pre_up_cm."
            )

        metadata["altura_preposicion_cm"] = h_takeoff_cm + pre_up_cm
        metadata["altura_inicial_descenso_cm"] = h0_cm
        metadata["altura_final_referencia_cm"] = hf_cm

        recorder = TelemetryRecorder(drone=drone, config=config)
        recorder.set_state(phase="antes_del_escalon", reference_cm=h0_cm)
        recorder.start()

        time.sleep(config.initial_hold_s)

        print(f"\nAplicando escalón descendente: move_down({config.step_cm} cm)...")
        metadata["tiempo_aplicacion_escalon_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_down", reference_cm=hf_cm)

        move_down_compatible(drone, config.step_cm)

        metadata["tiempo_fin_comando_s"] = recorder.elapsed()
        metadata["duracion_comando_s"] = metadata["tiempo_fin_comando_s"] - metadata["tiempo_aplicacion_escalon_s"]
        recorder.set_state(phase="despues_del_escalon", reference_cm=hf_cm)

        time.sleep(config.after_step_hold_s)
        recorder.stop()

        print("\nAterrizando...")
        aterrizo_ok = safe_land(drone)
        airborne = False
        if not aterrizo_ok:
            raise RuntimeError("El aterrizaje automático falló. Revisar dron antes de repetir la práctica.")

        metadata["timestamp_fin"] = time.strftime("%Y-%m-%d %H:%M:%S")
        metadata["bateria_final"] = safe_get_battery(drone)

        df = save_results(recorder.samples, config, metadata)
        plot_results(df, config)
        plot_descent_focus(df, prefix)
        print_quality_check(df)

        metrics = estimate_descent_metrics(df, config.step_cm)
        metadata["metricas_preliminares"] = metrics
        with open(config.output_metadata, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=4, ensure_ascii=False)

        save_descent_summary(metadata, prefix)

        print("\nExperimento diferenciado de escalón descendente completado.")
        print("Archivos clave:")
        print(f"  - {config.output_csv}")
        print(f"  - {config.output_metadata}")
        print(f"  - {config.output_plot}")
        print(f"  - datos/{prefix}_resumen.csv")
        print(f"  - salidas/{prefix}_comparacion.png")

    except KeyboardInterrupt:
        print("\nInterrupción manual detectada.")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando aterrizar por seguridad...")
            safe_land(drone)
        raise

    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR] Experimento de descenso: {exc}")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando estabilizar y aterrizar por seguridad...")
            safe_land(drone)
        raise

    finally:
        try:
            if hasattr(drone, "is_flying") and not getattr(drone, "is_flying"):
                drone.end()
            elif not airborne:
                drone.end()
        except Exception:
            pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Equipo 3 — Escalón descendente con Tello.")
    parser.add_argument("--mock", action="store_true", help="Ejecuta simulación sin dron real.")
    parser.add_argument("--step-cm", type=int, default=30, help="Magnitud del descenso en cm. Recomendado: 30.")
    parser.add_argument("--pre-up-cm", type=int, default=30, help="Subida previa para iniciar el descenso desde zona segura. Recomendado: 30.")
    parser.add_argument("--sample-period", type=float, default=0.10, help="Periodo de muestreo en segundos. Recomendado: 0.10.")
    parser.add_argument("--initial-hold", type=float, default=3.0, help="Tiempo antes del escalón descendente, en segundos.")
    parser.add_argument("--after-hold", type=float, default=8.0, help="Tiempo después del escalón descendente, en segundos.")
    parser.add_argument("--prefix", default="equipo03_descenso", help="Prefijo de archivos de salida.")
    args = parser.parse_args()

    if args.step_cm < 20:
        parser.error("El SDK del Tello requiere movimientos de al menos 20 cm.")
    if args.step_cm > 40:
        parser.error("Para clase se recomienda no exceder 40 cm en descenso.")
    if args.pre_up_cm < 20:
        parser.error("El preposicionamiento debe ser al menos 20 cm.")
    if args.pre_up_cm > 50:
        parser.error("Para clase se recomienda no exceder 50 cm de subida previa.")
    return args


if __name__ == "__main__":
    args = parse_args()
    cfg = build_descent_config(
        ExperimentConfig(
            step_cm=args.step_cm,
            sample_period_s=args.sample_period,
            initial_hold_s=args.initial_hold,
            after_step_hold_s=args.after_hold,
        ),
        step_cm=args.step_cm,
        prefix=args.prefix,
    )

    try:
        run_descent_experiment(
            mock=args.mock,
            config=cfg,
            pre_up_cm=args.pre_up_cm,
            prefix=args.prefix,
        )
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR GENERAL] {exc}")
        sys.exit(1)
