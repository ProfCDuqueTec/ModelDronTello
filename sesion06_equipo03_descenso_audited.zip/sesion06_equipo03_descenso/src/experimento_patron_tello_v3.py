"""
Sesión 6 — Bloque 2: Experimento patrón común, versión 3
MR2023 Modelación para Automatización

Objetivo didáctico:
    Generar un CSV útil y seguro para el análisis guiado de la respuesta vertical
    del dron ante un escalón relativo de altura.

Decisión de diseño v3:
    No se fuerza 0.50 m -> 0.80 m mediante ajustes automáticos agresivos.
    Se usa la altura real estable después del despegue como condición inicial:

        h0_real -> h0_real + step_cm

    Esto reduce riesgo operativo y simplifica la explicación a estudiantes.

Uso:
    python src/experimento_patron_tello_v3.py
    python src/experimento_patron_tello_v3.py --mock
    python src/experimento_patron_tello_v3.py --sample-period 0.10 --step-cm 30
"""

from __future__ import annotations

import argparse
import json
import math
import random
import statistics
import sys
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

# Backend no interactivo: evita errores Tcl/Tk en Windows al guardar gráficas.
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

try:
    from djitellopy import Tello
except ImportError:
    Tello = None


@dataclass
class ExperimentConfig:
    # Experimento recomendado para clase: escalón relativo moderado.
    step_cm: int = 30

    # Tiempos de adquisición.
    initial_hold_s: float = 3.0
    after_step_hold_s: float = 8.0
    sample_period_s: float = 0.10

    # Seguridad operativa.
    min_battery_percent: int = 35
    max_allowed_final_height_cm: int = 150
    min_allowed_initial_height_cm: int = 50
    max_allowed_initial_height_cm: int = 120
    takeoff_settle_s: float = 3.0
    command_speed_cm_s: int = 20

    # Archivos.
    output_csv: str = "datos/experimento_patron_escalon_030cm.csv"
    output_plot: str = "salidas/experimento_patron_escalon_030cm.png"
    output_metadata: str = "datos/experimento_patron_escalon_030cm_metadata.json"


class MockTello:
    """Simulador mínimo para probar el flujo sin conectar un dron real."""

    def __init__(self) -> None:
        self.height_cm = 85.0
        self.battery = 85
        self.temperature = 28
        self.is_flying = False
        self._step_start_time: float | None = None
        self._step_start_height = 85.0
        self._step_target_height = 115.0
        self._tau = 1.10

    def connect(self) -> None:
        print("[MOCK] Conectado al dron simulado.")

    def get_battery(self) -> int:
        return self.battery

    def get_temperature(self) -> int:
        return self.temperature

    def get_height(self) -> int:
        if self._step_start_time is not None:
            elapsed = time.monotonic() - self._step_start_time
            y = self._step_start_height + (self._step_target_height - self._step_start_height) * (
                1 - math.exp(-elapsed / self._tau)
            )
            noise = random.uniform(-1.5, 1.5)
            self.height_cm = y + noise
        return int(round(self.height_cm))

    def takeoff(self) -> None:
        print("[MOCK] Despegue.")
        self.is_flying = True
        self.height_cm = 85.0
        time.sleep(1.0)

    def land(self) -> None:
        print("[MOCK] Aterrizaje.")
        self.is_flying = False
        self.height_cm = 0.0
        time.sleep(0.5)

    def end(self) -> None:
        print("[MOCK] Fin de conexión.")

    def set_speed(self, cm_s: int) -> None:
        print(f"[MOCK] Velocidad configurada a {cm_s} cm/s.")

    def send_rc_control(self, lr: int, fb: int, ud: int, yaw: int) -> None:
        print(f"[MOCK] rc {lr} {fb} {ud} {yaw}")

    def emergency(self) -> None:
        print("[MOCK] Emergency: motores detenidos.")
        self.is_flying = False

    def move_up(self, cm: int) -> None:
        print(f"[MOCK] Comando up {cm} cm.")
        self._step_start_height = float(self.get_height())
        self._step_target_height = self._step_start_height + cm
        self._step_start_time = time.monotonic()
        # Simula que el comando es bloqueante, como ocurre con Tello real.
        time.sleep(2.8)


def ensure_output_dirs(config: ExperimentConfig) -> None:
    Path(config.output_csv).parent.mkdir(parents=True, exist_ok=True)
    Path(config.output_plot).parent.mkdir(parents=True, exist_ok=True)
    Path(config.output_metadata).parent.mkdir(parents=True, exist_ok=True)


def create_drone(mock: bool) -> Any:
    if mock:
        return MockTello()
    if Tello is None:
        raise RuntimeError("No se pudo importar djitellopy. Instala dependencias con: pip install -r requirements.txt")
    # retry_count=1 reduce bucles largos de reintentos ante fallas de seguridad.
    return Tello(retry_count=1)


def safe_get_height_cm(drone: Any) -> float:
    try:
        return float(drone.get_height())
    except Exception as exc:  # noqa: BLE001
        print(f"[ADVERTENCIA] No se pudo leer altura: {exc}")
        return float("nan")


def safe_get_battery(drone: Any) -> float:
    try:
        return float(drone.get_battery())
    except Exception:
        return float("nan")


def safe_get_temperature(drone: Any) -> float:
    try:
        return float(drone.get_temperature())
    except Exception:
        return float("nan")


def median_height_cm(drone: Any, n: int = 9, sample_period_s: float = 0.08) -> float:
    readings: list[float] = []
    for _ in range(n):
        h = safe_get_height_cm(drone)
        if not math.isnan(h):
            readings.append(h)
        time.sleep(sample_period_s)
    if not readings:
        return float("nan")
    return float(statistics.median(readings))


class TelemetryRecorder:
    """Registra telemetría en un hilo independiente durante el comando bloqueante."""

    def __init__(self, drone: Any, config: ExperimentConfig) -> None:
        self.drone = drone
        self.config = config
        self.samples: list[dict[str, float | str]] = []
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._t0: float | None = None
        self._phase = "preparacion"
        self._reference_cm = float("nan")

    def start(self) -> None:
        self._t0 = time.monotonic()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def elapsed(self) -> float:
        if self._t0 is None:
            return 0.0
        return time.monotonic() - self._t0

    def set_state(self, phase: str, reference_cm: float) -> None:
        with self._lock:
            self._phase = phase
            self._reference_cm = reference_cm

    def _snapshot_state(self) -> tuple[str, float]:
        with self._lock:
            return self._phase, self._reference_cm

    def _run(self) -> None:
        next_sample_time = time.monotonic()
        while not self._stop_event.is_set():
            now = time.monotonic()
            if now < next_sample_time:
                time.sleep(min(0.005, next_sample_time - now))
                continue

            t = self.elapsed()
            phase, reference_cm = self._snapshot_state()
            h_cm = safe_get_height_cm(self.drone)
            sample = {
                "tiempo": t,
                "altura": h_cm / 100.0,
                "referencia": reference_cm / 100.0,
                "altura_cm": h_cm,
                "referencia_cm": reference_cm,
                "bateria": safe_get_battery(self.drone),
                "temperatura": safe_get_temperature(self.drone),
                "fase": phase,
            }
            self.samples.append(sample)
            next_sample_time += self.config.sample_period_s


def save_results(samples: list[dict[str, float | str]], config: ExperimentConfig, metadata: dict[str, Any]) -> pd.DataFrame:
    df = pd.DataFrame(samples)
    df.to_csv(config.output_csv, index=False, encoding="utf-8-sig")

    with open(config.output_metadata, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=4, ensure_ascii=False)

    print(f"\nCSV guardado en: {config.output_csv}")
    print(f"Metadatos guardados en: {config.output_metadata}")
    return df


def plot_results(df: pd.DataFrame, config: ExperimentConfig) -> None:
    plt.figure(figsize=(9, 5))
    plt.plot(df["tiempo"], df["referencia"], "--", linewidth=1.5, label="Referencia experimental [m]")
    plt.plot(df["tiempo"], df["altura"], linewidth=1.7, label="Altura medida [m]")
    plt.grid(True)
    plt.xlabel("Tiempo [s]")
    plt.ylabel("Altura [m]")
    plt.title("Experimento patrón común: escalón vertical relativo")
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(config.output_plot, dpi=200)
    plt.close()
    print(f"Gráfica guardada en: {config.output_plot}")


def print_quality_check(df: pd.DataFrame) -> None:
    n = len(df)
    duration = df["tiempo"].max() - df["tiempo"].min() if n else float("nan")
    dt = df["tiempo"].diff().dropna()
    dt_med = dt.median() if not dt.empty else float("nan")
    fs = 1.0 / dt_med if dt_med and dt_med > 0 else float("nan")
    large_gaps = dt[dt > 3 * dt_med] if not dt.empty and dt_med > 0 else pd.Series(dtype=float)

    print("\nValidación rápida del dataset")
    print("--------------------------------")
    print(f"Muestras registradas: {n}")
    print(f"Duración registrada: {duration:.2f} s")
    print(f"dt mediano: {dt_med:.3f} s")
    print(f"Frecuencia efectiva aproximada: {fs:.2f} Hz")
    print(f"Brechas grandes de muestreo: {len(large_gaps)}")

    if "fase" in df.columns:
        print("Muestras por fase:")
        print(df["fase"].value_counts().to_string())

    for phase_name in ["antes_del_escalon", "durante_comando_up", "despues_del_escalon"]:
        g = df[df["fase"] == phase_name] if "fase" in df.columns else pd.DataFrame()
        if not g.empty:
            print(
                f"{phase_name}: h_prom = {g['altura'].mean():.3f} m, "
                f"h_min = {g['altura'].min():.3f} m, h_max = {g['altura'].max():.3f} m"
            )


def neutral_rc(drone: Any) -> None:
    try:
        drone.send_rc_control(0, 0, 0, 0)
    except Exception:
        pass


def safe_land(drone: Any) -> bool:
    """Intento único-controlado de aterrizaje. Evita cascadas largas de retry."""
    try:
        neutral_rc(drone)
        time.sleep(0.3)
        drone.land()
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"No se pudo aterrizar automáticamente: {exc}")
        print("ATENCIÓN: si el dron sigue en aire, usar el procedimiento físico de seguridad del laboratorio.")
        print("No se enviará 'emergency' automáticamente, porque detiene motores de inmediato y puede causar caída.")
        try:
            # Evita que __del__/end intente volver a aterrizar en cascada si el estado interno quedó inconsistente.
            drone.is_flying = False
        except Exception:
            pass
        return False


def validate_config_for_real_drone(config: ExperimentConfig, mock: bool) -> None:
    if config.step_cm < 20 or config.step_cm > 60:
        raise ValueError("Para clase se recomienda un escalón entre 20 y 60 cm. Usa --step-cm 20, 30, 40, 50 o 60.")

    if not mock and config.sample_period_s < 0.08:
        print(
            "[ADVERTENCIA] sample_period_s menor que 0.08 s no aporta información confiable adicional "
            "con Tello real. Se ajusta automáticamente a 0.08 s."
        )
        config.sample_period_s = 0.08

    if config.sample_period_s > 0.20:
        print("[ADVERTENCIA] Muestreo lento. Para identificación se recomienda 0.08–0.10 s.")


def run_experiment(mock: bool = False, config: ExperimentConfig | None = None) -> None:
    config = config or ExperimentConfig()
    validate_config_for_real_drone(config, mock)
    ensure_output_dirs(config)

    drone = create_drone(mock)
    metadata: dict[str, Any] = {
        "curso": "MR2023 Modelación para Automatización",
        "sesion": "Sesión 6",
        "bloque": "Bloque 2 — Experimento patrón común",
        "experimento": "Escalón relativo de altura desde hover estable",
        "configuracion": asdict(config),
        "modo_mock": mock,
        "timestamp_inicio": time.strftime("%Y-%m-%d %H:%M:%S"),
        "nota_v3": (
            "Se elimina referencia nominal y ajuste automático de altura inicial. "
            "La referencia del CSV es la referencia experimental real: h0_medido + step_cm."
        ),
    }

    airborne = False
    recorder: TelemetryRecorder | None = None

    try:
        print("Conectando con el dron...")
        drone.connect()
        battery = safe_get_battery(drone)
        metadata["bateria_inicial"] = battery
        print(f"Batería inicial: {battery:.0f} %")

        if not mock and battery < config.min_battery_percent:
            raise RuntimeError(f"Batería insuficiente. Se recomienda al menos {config.min_battery_percent} %.")

        input("\nVerifica zona despejada y autorización del profesor. Presiona ENTER para despegar...")

        print("Despegando...")
        drone.takeoff()
        airborne = True
        time.sleep(config.takeoff_settle_s)

        try:
            drone.set_speed(config.command_speed_cm_s)
            print(f"Velocidad de comando configurada: {config.command_speed_cm_s} cm/s")
        except Exception as exc:  # noqa: BLE001
            print(f"[ADVERTENCIA] No se pudo configurar velocidad: {exc}")

        h0_cm = median_height_cm(drone, n=9, sample_period_s=0.08)
        if math.isnan(h0_cm):
            raise RuntimeError("No se pudo medir la altura inicial estable.")

        h0_cm = float(round(h0_cm))
        hf_cm = h0_cm + config.step_cm

        print("\nCondición inicial aceptada sin ajuste automático agresivo")
        print(f"Altura inicial real medida: {h0_cm:.0f} cm")
        print(f"Escalón relativo aplicado: +{config.step_cm} cm")
        print(f"Referencia experimental: {h0_cm:.0f} cm -> {hf_cm:.0f} cm")
        print(f"Muestreo objetivo: {1/config.sample_period_s:.1f} Hz")

        if h0_cm < config.min_allowed_initial_height_cm or h0_cm > config.max_allowed_initial_height_cm:
            raise RuntimeError(
                f"Altura inicial fuera de rango seguro para esta práctica: {h0_cm:.0f} cm. "
                f"Rango recomendado: {config.min_allowed_initial_height_cm}–{config.max_allowed_initial_height_cm} cm."
            )

        if hf_cm > config.max_allowed_final_height_cm:
            raise RuntimeError(
                f"La altura final estimada sería {hf_cm:.0f} cm, mayor que el límite de clase "
                f"({config.max_allowed_final_height_cm} cm). Reduce --step-cm."
            )

        metadata["altura_inicial_real_cm"] = h0_cm
        metadata["altura_final_referencia_cm"] = hf_cm
        metadata["step_cm"] = config.step_cm

        recorder = TelemetryRecorder(drone=drone, config=config)
        recorder.set_state(phase="antes_del_escalon", reference_cm=h0_cm)
        recorder.start()

        time.sleep(config.initial_hold_s)

        print(f"\nAplicando escalón: comando move_up({config.step_cm} cm)...")
        metadata["tiempo_aplicacion_escalon_s"] = recorder.elapsed()
        recorder.set_state(phase="durante_comando_up", reference_cm=hf_cm)

        drone.move_up(config.step_cm)

        metadata["tiempo_fin_comando_s"] = recorder.elapsed()
        metadata["duracion_comando_s"] = metadata["tiempo_fin_comando_s"] - metadata["tiempo_aplicacion_escalon_s"]
        recorder.set_state(phase="despues_del_escalon", reference_cm=hf_cm)

        time.sleep(config.after_step_hold_s)
        recorder.stop()

        print("\nAterrizando...")
        if not safe_land(drone):
            raise RuntimeError("El aterrizaje automático falló. Revisar dron antes de repetir la práctica.")
        airborne = False

        metadata["timestamp_fin"] = time.strftime("%Y-%m-%d %H:%M:%S")
        metadata["bateria_final"] = safe_get_battery(drone)

        df = save_results(recorder.samples, config, metadata)
        plot_results(df, config)
        print_quality_check(df)

        print("\nExperimento patrón completado correctamente.")

    except KeyboardInterrupt:
        print("\nInterrupción manual detectada.")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando aterrizar por seguridad...")
            safe_land(drone)
        sys.exit(1)

    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR] {exc}")
        if recorder is not None:
            recorder.stop()
        if airborne:
            print("Intentando estabilizar y aterrizar por seguridad...")
            safe_land(drone)
        sys.exit(1)

    finally:
        try:
            # Evita cascadas de aterrizaje si el estado interno quedó inconsistente.
            if hasattr(drone, "is_flying") and not getattr(drone, "is_flying"):
                drone.end()
            elif not airborne:
                drone.end()
        except Exception:
            pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Experimento patrón común de altura con Tello, versión 3.")
    parser.add_argument("--mock", action="store_true", help="Ejecuta simulación sin dron real.")
    parser.add_argument("--step-cm", type=int, default=30, help="Magnitud del escalón relativo en cm. Recomendado: 30.")
    parser.add_argument("--sample-period", type=float, default=0.10, help="Periodo de muestreo en segundos. Recomendado: 0.10.")
    parser.add_argument("--initial-hold", type=float, default=3.0, help="Tiempo antes del escalón, en segundos.")
    parser.add_argument("--after-hold", type=float, default=8.0, help="Tiempo después del escalón, en segundos.")
    parser.add_argument("--output-csv", default=None, help="Ruta de salida del CSV.")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = ExperimentConfig(
        step_cm=args.step_cm,
        sample_period_s=args.sample_period,
        initial_hold_s=args.initial_hold,
        after_step_hold_s=args.after_hold,
    )
    if args.output_csv:
        cfg.output_csv = args.output_csv
        stem = Path(args.output_csv).stem
        cfg.output_plot = str(Path("salidas") / f"{stem}.png")
        cfg.output_metadata = str(Path("datos") / f"{stem}_metadata.json")

    run_experiment(mock=args.mock, config=cfg)
