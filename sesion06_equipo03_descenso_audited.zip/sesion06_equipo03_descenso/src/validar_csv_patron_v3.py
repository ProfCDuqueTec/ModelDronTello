"""Validación cuantitativa del CSV del experimento patrón, versión 3."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def rms(x: pd.Series | np.ndarray) -> float:
    arr = np.asarray(x, dtype=float)
    return float(np.sqrt(np.nanmean(arr**2)))


def analyze(csv_path: str, plot_path: str | None = None) -> None:
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"No existe el archivo: {csv_path}")

    df = pd.read_csv(path)
    print(f"\nArchivo: {path}")
    print(f"Columnas: {list(df.columns)}")
    print(f"Muestras: {len(df)}")

    required = {"tiempo", "altura", "referencia"}
    missing = required - set(df.columns)
    if missing:
        print(f"[ERROR] Faltan columnas mínimas: {missing}")
        return

    t = df["tiempo"]
    dt = t.diff().dropna()
    dt_med = float(dt.median()) if not dt.empty else float("nan")
    dt_mean = float(dt.mean()) if not dt.empty else float("nan")
    fs = 1 / dt_med if dt_med and dt_med > 0 else float("nan")
    gaps = dt[dt > 3 * dt_med] if dt_med and dt_med > 0 else pd.Series(dtype=float)

    print("\nMuestreo")
    print("--------")
    print(f"Duración total: {t.max() - t.min():.3f} s")
    print(f"dt mediano: {dt_med:.4f} s")
    print(f"dt promedio: {dt_mean:.4f} s")
    print(f"Frecuencia aproximada: {fs:.2f} Hz")
    print(f"Brechas grandes detectadas: {len(gaps)}")
    if len(gaps) > 0:
        print(gaps.to_string())

    print("\nEstadística por fase")
    print("--------------------")
    if "fase" in df.columns:
        summary = df.groupby("fase").agg(
            muestras=("altura", "count"),
            t_min=("tiempo", "min"),
            t_max=("tiempo", "max"),
            h_media=("altura", "mean"),
            h_mediana=("altura", "median"),
            h_std=("altura", "std"),
            h_min=("altura", "min"),
            h_max=("altura", "max"),
            r_media=("referencia", "mean"),
        )
        print(summary.to_string(float_format=lambda x: f"{x:.4f}"))
    else:
        print("No existe columna 'fase'.")

    pre = df[df.get("fase", "") == "antes_del_escalon"] if "fase" in df.columns else df.head(max(5, len(df)//4))
    post = df[df.get("fase", "") == "despues_del_escalon"] if "fase" in df.columns else df.tail(max(5, len(df)//4))
    trans = df[df.get("fase", "") == "durante_comando_up"] if "fase" in df.columns else pd.DataFrame()

    if pre.empty:
        pre = df.head(10)
    if post.empty:
        post = df.tail(10)

    h0 = float(pre["altura"].tail(min(10, len(pre))).mean())
    hf_last10 = float(post["altura"].tail(min(10, len(post))).mean())
    hf_post = float(post["altura"].mean())
    r0 = float(pre["referencia"].tail(min(10, len(pre))).mean())
    rf = float(post["referencia"].tail(min(10, len(post))).mean())
    delta_r = rf - r0

    print("\nIndicadores para modelación")
    print("---------------------------")
    print(f"h0 estimada: {h0:.3f} m")
    print(f"hf promedio post-escalón: {hf_post:.3f} m")
    print(f"hf últimas muestras: {hf_last10:.3f} m")
    print(f"r0: {r0:.3f} m")
    print(f"rf: {rf:.3f} m")
    print(f"Delta r: {delta_r:.3f} m")

    if abs(delta_r) > 1e-9:
        print(f"K usando hf post-promedio: {(hf_post - h0) / delta_r:.3f}")
        print(f"K usando hf últimas muestras: {(hf_last10 - h0) / delta_r:.3f}")

    if not post.empty:
        e_post = post["altura"] - post["referencia"]
        print(f"Error RMS post-escalón contra referencia: {rms(e_post):.4f} m")
        print(f"Sesgo promedio post-escalón: {float(e_post.mean()):.4f} m")

    if trans.empty:
        print("\n[ADVERTENCIA DIDÁCTICA]")
        print("No hay muestras etiquetadas como 'durante_comando_up'. Revisar si el hilo de adquisición estuvo activo durante el comando.")

    if len(gaps) > 0:
        print("\n[ADVERTENCIA DIDÁCTICA]")
        print("Hay brechas grandes de muestreo. Si ocurren durante la transición, la estimación de tau por método del 63 % no es confiable.")

    if plot_path is None:
        plot_path = str(Path("salidas") / f"{path.stem}_validacion.png")
    Path(plot_path).parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(9, 5))
    plt.plot(df["tiempo"], df["referencia"], "--", linewidth=1.5, label="Referencia [m]")
    plt.plot(df["tiempo"], df["altura"], linewidth=1.7, label="Altura medida [m]")
    plt.grid(True)
    plt.xlabel("Tiempo [s]")
    plt.ylabel("Altura [m]")
    plt.title("Validación del experimento patrón")
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(plot_path, dpi=200)
    plt.close()
    print(f"\nGráfica de validación guardada en: {plot_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Valida el CSV del experimento patrón de altura, versión 3.")
    parser.add_argument("--csv", default="datos/experimento_patron_escalon_030cm.csv", help="Ruta del archivo CSV.")
    parser.add_argument("--plot", default=None, help="Ruta opcional para guardar la gráfica de validación.")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    analyze(args.csv, args.plot)
